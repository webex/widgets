type Enum<T extends Record<string, unknown>> = T[keyof T];

/**
 * @ignore
 * @module METRIC_EVENT_NAMES
 * @export
 * @description
 * A constant object containing all metric event names used for tracking various agent and task-related events
 * within the Contact Center plugin. Each property represents a specific event and its corresponding string value
 * as reported in metrics.
 *
 * @property {string} STATION_LOGIN_SUCCESS - Event name for successful station login.
 * @property {string} STATION_LOGIN_FAILED - Event name for failed station login.
 * @property {string} STATION_LOGOUT_SUCCESS - Event name for successful station logout.
 * @property {string} STATION_LOGOUT_FAILED - Event name for failed station logout.
 * @property {string} STATION_RELOGIN_SUCCESS - Event name for successful station relogin.
 * @property {string} STATION_RELOGIN_FAILED - Event name for failed station relogin.
 * @property {string} AGENT_STATE_CHANGE_SUCCESS - Event name for successful agent state change.
 * @property {string} AGENT_STATE_CHANGE_FAILED - Event name for failed agent state change.
 * @property {string} FETCH_BUDDY_AGENTS_SUCCESS - Event name for successfully fetching buddy agents.
 * @property {string} FETCH_BUDDY_AGENTS_FAILED - Event name for failed attempt to fetch buddy agents.
 * @property {string} WEBSOCKET_REGISTER_SUCCESS - Event name for successful websocket registration.
 * @property {string} WEBSOCKET_REGISTER_FAILED - Event name for failed websocket registration.
 * @property {string} AGENT_RONA - Event name for agent RONA (Ring No Answer).
 * @property {string} AGENT_CONTACT_ASSIGN_FAILED - Event name for failed agent contact assignment.
 * @property {string} AGENT_INVITE_FAILED - Event name for failed agent invite.
 *
 * @property {string} TASK_ACCEPT_SUCCESS - Event name for successful task acceptance.
 * @property {string} TASK_ACCEPT_FAILED - Event name for failed task acceptance.
 * @property {string} TASK_DECLINE_SUCCESS - Event name for successful task decline.
 * @property {string} TASK_DECLINE_FAILED - Event name for failed task decline.
 * @property {string} TASK_END_SUCCESS - Event name for successful task end.
 * @property {string} TASK_END_FAILED - Event name for failed task end.
 * @property {string} TASK_WRAPUP_SUCCESS - Event name for successful task wrap-up.
 * @property {string} TASK_WRAPUP_FAILED - Event name for failed task wrap-up.
 * @property {string} TASK_HOLD_SUCCESS - Event name for successful task hold.
 * @property {string} TASK_HOLD_FAILED - Event name for failed task hold.
 * @property {string} TASK_RESUME_SUCCESS - Event name for successful task resume.
 * @property {string} TASK_RESUME_FAILED - Event name for failed task resume.
 * @property {string} TASK_CONSULT_START_SUCCESS - Event name for successful consult start.
 * @property {string} TASK_CONSULT_START_FAILED - Event name for failed consult start.
 * @property {string} TASK_CONSULT_END_SUCCESS - Event name for successful consult end.
 * @property {string} TASK_CONSULT_END_FAILED - Event name for failed consult end.
 * @property {string} TASK_TRANSFER_SUCCESS - Event name for successful task transfer.
 * @property {string} TASK_TRANSFER_FAILED - Event name for failed task transfer.
 * @property {string} TASK_RESUME_RECORDING_SUCCESS - Event name for successful resume of recording.
 * @property {string} TASK_RESUME_RECORDING_FAILED - Event name for failed resume of recording.
 * @property {string} TASK_PAUSE_RECORDING_SUCCESS - Event name for successful pause of recording.
 * @property {string} TASK_PAUSE_RECORDING_FAILED - Event name for failed pause of recording.
 * @property {string} TASK_ACCEPT_CONSULT_SUCCESS - Event name for successful consult acceptance.
 * @property {string} TASK_ACCEPT_CONSULT_FAILED - Event name for failed consult acceptance.
 * @property {string} TASK_AUTO_ANSWER_SUCCESS - Event name for successful auto-answer.
 * @property {string} TASK_AUTO_ANSWER_FAILED - Event name for failed auto-answer.
 *
 * @property {string} TASK_CONFERENCE_START_SUCCESS - Event name for successful conference start.
 * @property {string} TASK_CONFERENCE_START_FAILED - Event name for failed conference start.
 * @property {string} TASK_CONFERENCE_END_SUCCESS - Event name for successful conference end.
 * @property {string} TASK_CONFERENCE_END_FAILED - Event name for failed conference end.
 * @property {string} TASK_CONFERENCE_TRANSFER_SUCCESS - Event name for successful conference transfer.
 * @property {string} TASK_CONFERENCE_TRANSFER_FAILED - Event name for failed conference transfer.
 *
 * @property {string} TASK_OUTDIAL_SUCCESS - Event name for successful outdial task.
 * @property {string} TASK_OUTDIAL_FAILED - Event name for failed outdial task.
 *
 * @property {string} UPLOAD_LOGS_SUCCESS - Event name for successful log upload.
 * @property {string} UPLOAD_LOGS_FAILED - Event name for failed log upload.
 * @property {string} WEBSOCKET_DEREGISTER_SUCCESS - Event name for successful websocket deregistration.
 * @property {string} WEBSOCKET_DEREGISTER_FAIL - Event name for failed websocket deregistration.
 *
 * @property {string} AGENT_DEVICE_TYPE_UPDATE_SUCCESS - Event name for successful agent device type update.
 * @property {string} AGENT_DEVICE_TYPE_UPDATE_FAILED - Event name for failed agent device type update.
 *
 * @property {string} OUTDIAL_ANI_EP_FETCH_SUCCESS - Event name for successful outdial ANI entries fetch.
 * @property {string} OUTDIAL_ANI_EP_FETCH_FAILED - Event name for failed outdial ANI entries fetch.
 *
 * @readonly
 */
export const METRIC_EVENT_NAMES = {
  STATION_LOGIN_SUCCESS: 'Station Login Success',
  STATION_LOGIN_FAILED: 'Station Login Failed',
  STATION_LOGOUT_SUCCESS: 'Station Logout Success',
  STATION_LOGOUT_FAILED: 'Station Logout Failed',
  STATION_RELOGIN_SUCCESS: 'Station Relogin Success',
  STATION_RELOGIN_FAILED: 'Station Relogin Failed',
  AGENT_STATE_CHANGE_SUCCESS: 'Agent State Change Success',
  AGENT_STATE_CHANGE_FAILED: 'Agent State Change Failed',
  FETCH_BUDDY_AGENTS_SUCCESS: 'Fetch Buddy Agents Success',
  FETCH_BUDDY_AGENTS_FAILED: 'Fetch Buddy Agents Failed',
  WEBSOCKET_REGISTER_SUCCESS: 'Websocket Register Success',
  WEBSOCKET_REGISTER_FAILED: 'Websocket Register Failed',
  AGENT_RONA: 'Agent RONA',
  AGENT_CONTACT_ASSIGN_FAILED: 'Agent Contact Assign Failed',
  AGENT_INVITE_FAILED: 'Agent Invite Failed',

  // Basic Tasks
  TASK_ACCEPT_SUCCESS: 'Task Accept Success',
  TASK_ACCEPT_FAILED: 'Task Accept Failed',
  TASK_DECLINE_SUCCESS: 'Task Decline Success',
  TASK_DECLINE_FAILED: 'Task Decline Failed',
  TASK_END_SUCCESS: 'Task End Success',
  TASK_END_FAILED: 'Task End Failed',
  TASK_WRAPUP_SUCCESS: 'Task Wrapup Success',
  TASK_WRAPUP_FAILED: 'Task Wrapup Failed',
  TASK_HOLD_SUCCESS: 'Task Hold Success',
  TASK_HOLD_FAILED: 'Task Hold Failed',
  TASK_RESUME_SUCCESS: 'Task Resume Success',
  TASK_RESUME_FAILED: 'Task Resume Failed',

  // Advanced Tasks
  TASK_CONSULT_START_SUCCESS: 'Task Consult Start Success',
  TASK_CONSULT_START_FAILED: 'Task Consult Start Failed',
  TASK_CONSULT_END_SUCCESS: 'Task Consult End Success',
  TASK_CONSULT_END_FAILED: 'Task Consult End Failed',
  TASK_TRANSFER_SUCCESS: 'Task Transfer Success',
  TASK_TRANSFER_FAILED: 'Task Transfer Failed',
  TASK_RESUME_RECORDING_SUCCESS: 'Task Resume Recording Success',
  TASK_RESUME_RECORDING_FAILED: 'Task Resume Recording Failed',
  TASK_PAUSE_RECORDING_SUCCESS: 'Task Pause Recording Success',
  TASK_PAUSE_RECORDING_FAILED: 'Task Pause Recording Failed',
  TASK_ACCEPT_CONSULT_SUCCESS: 'Task Accept Consult Success',
  TASK_ACCEPT_CONSULT_FAILED: 'Task Accept Consult Failed',
  TASK_AUTO_ANSWER_SUCCESS: 'Task Auto Answer Success',
  TASK_AUTO_ANSWER_FAILED: 'Task Auto Answer Failed',

  // Conference Tasks
  TASK_CONFERENCE_START_SUCCESS: 'Task Conference Start Success',
  TASK_CONFERENCE_START_FAILED: 'Task Conference Start Failed',
  TASK_CONFERENCE_END_SUCCESS: 'Task Conference End Success',
  TASK_CONFERENCE_END_FAILED: 'Task Conference End Failed',
  TASK_CONFERENCE_TRANSFER_SUCCESS: 'Task Conference Transfer Success',
  TASK_CONFERENCE_TRANSFER_FAILED: 'Task Conference Transfer Failed',
  TASK_CONFERENCE_EXIT_SUCCESS: 'Task Conference Exit Success',
  TASK_CONFERENCE_EXIT_FAILED: 'Task Conference Exit Failed',
  TASK_CONFERENCE_PARTICIPANT_DROP_SUCCESS: 'Task Conference Participant Drop Success',
  TASK_CONFERENCE_PARTICIPANT_DROP_FAILED: 'Task Conference Participant Drop Failed',
  TASK_SWITCH_CALL_SUCCESS: 'Task Switch Call Success',
  TASK_SWITCH_CALL_FAILED: 'Task Switch Call Failed',

  TASK_OUTDIAL_SUCCESS: 'Task Outdial Success',
  TASK_OUTDIAL_FAILED: 'Task Outdial Failed',

  WXAPP_TASK_MUTE_SUCCESS: 'WxApp Task Mute Success',
  WXAPP_TASK_MUTE_FAILED: 'WxApp Task Mute Failed',
  WXAPP_TASK_DTMF_SUCCESS: 'WxApp Task Dtmf Success',
  WXAPP_TASK_DTMF_FAILED: 'WxApp Task Dtmf Failed',

  // WxApp Better Together
  WXAPP_TASK_ACCEPT_SUCCESS: 'WxApp Task Accept Success',
  WXAPP_TASK_ACCEPT_FAILED: 'WxApp Task Accept Failed',
  WXAPP_TASK_DECLINE_SUCCESS: 'WxApp Task Decline Success',
  WXAPP_TASK_DECLINE_FAILED: 'WxApp Task Decline Failed',
  WXAPP_SESSION_INIT_SUCCESS: 'WxApp Session Init Success',
  WXAPP_SESSION_INIT_FAILED: 'WxApp Session Init Failed',
  WXAPP_SESSION_SKIPPED: 'WxApp Session Skipped',
  WXAPP_USERSUB_PUBLISH_SUCCESS: 'WxApp Usersub Publish Success',
  WXAPP_USERSUB_PUBLISH_FAILED: 'WxApp Usersub Publish Failed',
  WXAPP_MERCURY_SUBSCRIBE_SUCCESS: 'WxApp Mercury Subscribe Success',
  WXAPP_MERCURY_SUBSCRIBE_FAILED: 'WxApp Mercury Subscribe Failed',

  UPLOAD_LOGS_SUCCESS: 'Upload Logs Success',
  UPLOAD_LOGS_FAILED: 'Upload Logs Failed',
  WEBSOCKET_DEREGISTER_SUCCESS: 'Websocket Deregister Success',
  WEBSOCKET_DEREGISTER_FAIL: 'Websocket Deregister Failed',

  AGENT_DEVICE_TYPE_UPDATE_SUCCESS: 'Agent Device Type Update Success',
  AGENT_DEVICE_TYPE_UPDATE_FAILED: 'Agent Device Type Update Failed',
  // WebSocket message events
  WEBSOCKET_EVENT_RECEIVED: 'Websocket Event Received',

  // EntryPoint API Events
  ENTRYPOINT_FETCH_SUCCESS: 'Entrypoint Fetch Success',
  ENTRYPOINT_FETCH_FAILED: 'Entrypoint Fetch Failed',

  // AddressBook API Events
  ADDRESSBOOK_FETCH_SUCCESS: 'AddressBook Fetch Success',
  ADDRESSBOOK_FETCH_FAILED: 'AddressBook Fetch Failed',

  // Queue API Events
  QUEUE_FETCH_SUCCESS: 'Queue Fetch Success',
  QUEUE_FETCH_FAILED: 'Queue Fetch Failed',

  // Outdial ANI Entries API Events
  OUTDIAL_ANI_EP_FETCH_SUCCESS: 'Outdial ANI Entries Fetch Success',
  OUTDIAL_ANI_EP_FETCH_FAILED: 'Outdial ANI Entries Fetch Failed',

  // Campaign Preview API Events
  CAMPAIGN_PREVIEW_ACCEPT_SUCCESS: 'Campaign Preview Accept Success',
  CAMPAIGN_PREVIEW_ACCEPT_FAILED: 'Campaign Preview Accept Failed',
  CAMPAIGN_PREVIEW_SKIP_SUCCESS: 'Campaign Preview Skip Success',
  CAMPAIGN_PREVIEW_SKIP_FAILED: 'Campaign Preview Skip Failed',
  CAMPAIGN_PREVIEW_REMOVE_SUCCESS: 'Campaign Preview Remove Success',
  CAMPAIGN_PREVIEW_REMOVE_FAILED: 'Campaign Preview Remove Failed',

  // AI Assistant Transcript events
  AI_ASSISTANT_SEND_EVENT_SUCCESS: 'AI Assistant Send Event Success',
  AI_ASSISTANT_SEND_EVENT_FAILED: 'AI Assistant Send Event Failed',
  AI_ASSISTANT_GET_REAL_TIME_ASSISTANCE_SUCCESS: 'AI Assistant Get Real Time Assistance Success',
  AI_ASSISTANT_GET_REAL_TIME_ASSISTANCE_FAILED: 'AI Assistant Get Real Time Assistance Failed',
  AI_ASSISTANT_SEND_REAL_TIME_ASSISTANCE_USER_ACTION_SUCCESS:
    'AI Assistant Send Real Time Assistance User Action Success',
  AI_ASSISTANT_SEND_REAL_TIME_ASSISTANCE_USER_ACTION_FAILED:
    'AI Assistant Send Real Time Assistance User Action Failed',
  AI_ASSISTANT_FETCH_HISTORIC_TRANSCRIPTS_SUCCESS:
    'AI Assistant Fetch Historic Transcripts Success',
  AI_ASSISTANT_FETCH_HISTORIC_TRANSCRIPTS_FAILED: 'AI Assistant Fetch Historic Transcripts Failed',
  AI_ASSISTANT_WELLNESS_ACTION_ACCEPTED: 'AI Assistant Wellness Action Accepted',
  AI_ASSISTANT_WELLNESS_ACTION_FAILED: 'AI Assistant Wellness Action Failed',
  AI_ASSISTANT_WELLNESS_EVENT_INVALID: 'AI Assistant Wellness Event Invalid',
  WELLBEING_BREAK_IDLE_CODE_FETCH_SUCCESS: 'Wellbeing Break Idle Code Fetch Success',
  WELLBEING_BREAK_IDLE_CODE_FETCH_FAILED: 'Wellbeing Break Idle Code Fetch Failed',

  // AI summary events
  AI_SUMMARY_GET_POST_CALL_SUCCESS: 'Post Call Summary Get Success',
  AI_SUMMARY_GET_POST_CALL_FAILED: 'Post Call Summary Get Failed',
  AI_SUMMARY_GET_MID_CALL_SUCCESS: 'Mid Call Summary Get Success',
  AI_SUMMARY_GET_MID_CALL_FAILED: 'Mid Call Summary Get Failed',
  AI_SUMMARY_POST_CALL_RESPONSE_SUCCESS: 'Post Call Summary Response Success',
  AI_SUMMARY_POST_CALL_RESPONSE_FAILED: 'Post Call Summary Response Failed',
  AI_SUMMARY_MID_CALL_RESPONSE_SUCCESS: 'Mid Call Summary Response Success',
  AI_SUMMARY_MID_CALL_RESPONSE_FAILED: 'Mid Call Summary Response Failed',

  // User Preference API Events
  USER_PREFERENCE_GET_SUCCESS: 'User Preference Get Success',
  USER_PREFERENCE_GET_FAILED: 'User Preference Get Failed',
  USER_PREFERENCE_CREATE_SUCCESS: 'User Preference Create Success',
  USER_PREFERENCE_CREATE_FAILED: 'User Preference Create Failed',
  USER_PREFERENCE_UPDATE_SUCCESS: 'User Preference Update Success',
  USER_PREFERENCE_UPDATE_FAILED: 'User Preference Update Failed',
  USER_PREFERENCE_DELETE_SUCCESS: 'User Preference Delete Success',
  USER_PREFERENCE_DELETE_FAILED: 'User Preference Delete Failed',
} as const;

/**
 * Represents the possible metric event names used within the metrics system.
 *
 * This type is derived from the keys of the `METRIC_EVENT_NAMES` constant, ensuring
 * type safety and consistency when referring to metric event names throughout the codebase.
 * @export
 * @typedef {Enum<typeof METRIC_EVENT_NAMES>} METRIC_EVENT_NAMES
 * @typeParam T - The type of the `METRIC_EVENT_NAMES` constant.
 *
 * @see {@link METRIC_EVENT_NAMES}
 */
export type METRIC_EVENT_NAMES = Enum<typeof METRIC_EVENT_NAMES>;

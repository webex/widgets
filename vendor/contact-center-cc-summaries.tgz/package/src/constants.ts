export const EVENT = 'event';
export const READY = 'ready';
export const TIMEOUT_DURATION = 20000; // 20 seconds timeout duration for webrtc registration
export const EMPTY_STRING = '';
export const PRODUCT_NAME = 'wxcc_sdk';
// FILE NAMES
export const LOG_PREFIX = 'PLUGIN_CC';
export const WEB_CALLING_SERVICE_FILE = 'WebCallingService';
export const CONFIG_FILE_NAME = 'config-index';
export const CC_FILE = 'cc';
export const WELLNESS_BREAK_HANDLER = 'Wellness_Break_Handler';
export const CONNECTION_SERVICE_FILE = 'connection-service';
export const WEB_SOCKET_MANAGER_FILE = 'WebSocketManager';
export const AQM_REQS_FILE = 'aqm-reqs';
export const WEBEX_REQUEST_FILE = 'WebexRequest';
export const TASK_MANAGER_FILE = 'TaskManager';
export const TASK_FILE = 'Task';
// AGENT OUTDIAL CONSTANTS
export const INBOUND_DIRECTION = 'INBOUND';
export const OUTDIAL_DIRECTION = 'OUTBOUND';
export const ATTRIBUTES = {};
export const OUTDIAL_MEDIA_TYPE = 'telephony';
export const OUTBOUND_TYPE = 'OUTDIAL';

// Log related constants
export const UNKNOWN_ERROR = 'Unknown error';
export const MERCURY_DISCONNECTED_SUCCESS = 'Mercury disconnected successfully';

// METHOD NAMES
export const METHODS = {
  REGISTER: 'register',
  DEREGISTER: 'deregister',
  GET_BUDDY_AGENTS: 'getBuddyAgents',
  CONNECT_WEBSOCKET: 'connectWebsocket',
  STATION_LOGIN: 'stationLogin',
  STATION_LOGOUT: 'stationLogout',
  STATION_RELOGIN: 'stationReLogin',
  SET_AGENT_STATE: 'setAgentState',
  HANDLE_WEBSOCKET_MESSAGE: 'handleWebsocketMessage',
  SETUP_EVENT_LISTENERS: 'setupEventListeners',
  GET_CONNECTION_CONFIG: 'getConnectionConfig',
  HANDLE_CONNECTION_LOST: 'handleConnectionLost',
  SILENT_RELOGIN: 'silentRelogin',
  HANDLE_DEVICE_TYPE: 'handleDeviceType',
  START_OUTDIAL: 'startOutdial',
  GET_QUEUES: 'getQueues',
  UPLOAD_LOGS: 'uploadLogs',
  UPDATE_AGENT_PROFILE: 'updateAgentProfile',
  GET_DEVICE_ID: 'getDeviceId',
  HANDLE_INCOMING_TASK: 'handleIncomingTask',
  HANDLE_TASK_HYDRATE: 'handleTaskHydrate',
  INCOMING_TASK_LISTENER: 'incomingTaskListener',
  ACCEPT: 'accept',
  REJECT: 'decline',
  HOLD: 'hold',
  RESUME: 'resume',
  HOLD_RESUME: 'holdResume',
  TRANSFER_CALL: 'transfer',
  CONSULT_TRANSFER: 'consultTransfer',
  CONSULT_CONFERENCE: 'consultConference',
  DROP_CONFERENCE_PARTICIPANT: 'dropConferenceParticipant',
  EXIT_CONFERENCE: 'exitConference',
  TRANSFER_CONFERENCE: 'transferConference',
  TOGGLE_MUTE: 'toggleMute',
  TRANSMIT_DTMF: 'transmitDtmf',
  COMPLETE_TRANSFER: 'completeTransfer',
  GET_OUTDIAL_ANI_ENTRIES: 'getOutdialAniEntries',
  ACCEPT_PREVIEW_CONTACT: 'acceptPreviewContact',
  SKIP_PREVIEW_CONTACT: 'skipPreviewContact',
  REMOVE_PREVIEW_CONTACT: 'removePreviewContact',
  GET_BASE_URL: 'getBaseUrl',
  SEND_EVENT: 'sendEvent',
  GET_REAL_TIME_ASSISTANCE: 'getRealTimeAssistance',
  SEND_REAL_TIME_ASSISTANCE_USER_ACTION: 'sendRealTimeAssistanceUserAction',
  FETCH_HISTORIC_TRANSCRIPTS: 'fetchHistoricTranscripts',
  REQUEST_WELLNESS_BREAK: 'requestWellnessBreak',
  RESPOND_TO_WELLNESS_BREAK: 'respondToWellnessBreak',
  GET_WELLBEING_BREAK_IDLE_CODE: 'getWellbeingBreakIdleCode',
  SET_MANAGE_WEBEX_CALLING_IN_WXCC: 'setManageWebexCallingInWxcc',
  IS_WX_BETTER_TOGETHER_ENABLED: 'isWxBetterTogetherEnabled',
  SYNC_WXAPP_MUTE_FROM_MERCURY: 'syncWxAppMuteFromMercury',
  GET_CALL_DETAILS_ON_WEBEX: 'getCallDetailsOnWebex',
  ENSURE_WXAPP_MERCURY_CONNECTED: 'ensureWxAppMercuryConnected',
};

export const AI_SUMMARY_ERROR_CODES = {
  POST_CALL_SUMMARY_DISABLED: 'POST_CALL_SUMMARY_DISABLED',
  MID_CALL_SUMMARY_DISABLED: 'MID_CALL_SUMMARY_DISABLED',
  AI_ASSISTANT_BASE_URL_NOT_AVAILABLE: 'AI_ASSISTANT_BASE_URL_NOT_AVAILABLE',
  POST_CALL_SUMMARY_TIMEOUT: 'POST_CALL_SUMMARY_TIMEOUT',
  MID_CALL_SUMMARY_TIMEOUT: 'MID_CALL_SUMMARY_TIMEOUT',
} as const;

export const AI_SUMMARY_INVALID_RESPONSE_PAYLOAD = 'AI_SUMMARY_INVALID_RESPONSE_PAYLOAD';

export const AI_ASSISTANT_CLIENT_TYPE = 'WxCC' as const;

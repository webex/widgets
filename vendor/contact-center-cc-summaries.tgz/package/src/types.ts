import {CallingClientConfig} from '@webex/calling';
import {
  SubmitBehavioralEvent,
  SubmitOperationalEvent,
  SubmitBusinessEvent,
} from '@webex/internal-plugin-metrics/src/metrics.types';
import * as Agent from './services/agent/types';
import * as Contact from './services/task/types';
import {
  AIFeatureFlags,
  Entity,
  Profile,
  CreateUserPreferenceRequest,
  UpdateUserPreferenceRequest,
} from './services/config/types';
import {PaginatedResponse, BaseSearchParams} from './utils/PageCache';

/**
 * Generic type for converting a const enum object into a union type of its values.
 * @template T The enum object type
 * @internal
 * @ignore
 */
type Enum<T extends Record<string, unknown>> = T[keyof T];

/**
 * HTTP methods supported by WebexRequest.
 * @enum {string}
 * @public
 * @example
 * const method: HTTP_METHODS = HTTP_METHODS.GET;
 * @ignore
 */
export const HTTP_METHODS = {
  /** HTTP GET method for retrieving data */
  GET: 'GET',
  /** HTTP POST method for creating resources */
  POST: 'POST',
  /** HTTP PATCH method for partial updates */
  PATCH: 'PATCH',
  /** HTTP PUT method for complete updates */
  PUT: 'PUT',
  /** HTTP DELETE method for removing resources */
  DELETE: 'DELETE',
} as const;

/**
 * Union type of HTTP methods.
 * @public
 * @example
 * function makeRequest(method: HTTP_METHODS) { ... }
 * @ignore
 */
export type HTTP_METHODS = Enum<typeof HTTP_METHODS>;

/**
 * Payload for making requests to Webex APIs.
 * @public
 * @example
 * const payload: WebexRequestPayload = {
 *   service: 'identity',
 *   resource: '/users',
 *   method: HTTP_METHODS.GET
 * };
 * @ignore
 */
export type WebexRequestPayload = {
  /** Service name to target */
  service?: string;
  /** Resource path within the service */
  resource?: string;
  /** HTTP method to use */
  method?: HTTP_METHODS;
  /** Full URI if not using service/resource pattern */
  uri?: string;
  /** Whether to add authorization header */
  addAuthHeader?: boolean;
  /** Request timeout in milliseconds */
  timeout?: number;
  /** Custom headers to include in request */
  headers?: {
    [key: string]: string | null;
  };
  /** Request body data */
  body?: object;
  /** Expected response status code */
  statusCode?: number;
  /** Whether to parse response as JSON */
  json?: boolean;
};

/**
 * Event listener function type.
 * @internal
 * @ignore
 */
type Listener = (e: string, data?: unknown) => void;

/**
 * Mercury event handler callback.
 * @internal
 * @ignore
 */
type MercuryEventHandler = (data?: unknown) => void;

/**
 * Event listener removal function type.
 * @internal
 * @ignore
 */
type ListenerOff = (e: string, handler?: MercuryEventHandler) => void;

/**
 * Service host configuration.
 * @internal
 * @ignore
 */
type ServiceHost = {
  /** Host URL/domain for the service */
  host: string;
  /** Time-to-live in seconds */
  ttl: number;
  /** Priority level for load balancing (lower is higher priority) */
  priority: number;
  /** Unique identifier for this host */
  id: string;
  /** Whether this is the home cluster for the user */
  homeCluster?: boolean;
};

/**
 * Configuration options for the Contact Center Plugin.
 * @interface CCPluginConfig
 * @public
 * @example
 * const config: CCPluginConfig = {
 *   allowMultiLogin: true,
 *   allowAutomatedRelogin: false,
 *   clientType: 'browser',
 *   isKeepAliveEnabled: true,
 *   force: false,
 *   metrics: { clientName: 'myClient', clientType: 'browser' },
 *   logging: { enable: true, verboseEvents: false },
 *   callingClientConfig: { ... }
 * };
 */
export interface CCPluginConfig {
  /** Whether to allow multiple logins from different devices */
  allowMultiLogin: boolean;
  /** Whether to automatically attempt relogin on connection loss */
  allowAutomatedRelogin: boolean;
  /** The type of client making the connection */
  clientType: string;
  /** Whether to enable keep-alive messages */
  isKeepAliveEnabled: boolean;
  /** Whether to force registration */
  force: boolean;
  /** Metrics configuration */
  metrics: {
    /** Name of the client for metrics */
    clientName: string;
    /** Type of client for metrics */
    clientType: string;
  };
  /** Logging configuration */
  logging: {
    /** Whether to enable logging */
    enable: boolean;
    /** Whether to log verbose events */
    verboseEvents: boolean;
  };
  /** Configuration for the calling client */
  callingClientConfig: CallingClientConfig;
  /** Whether to skip Mobius/WebRTC registration for browser login flows */
  disableWebRTCRegistration?: boolean;
  /** Whether wxApp Better Together (telephony REST + usersub) is enabled at init (WXCC-6026) */
  enableWxBetterTogether?: boolean;
}

/**
 * Logger interface for standardized logging throughout the plugin.
 * @public
 * @example
 * logger.log('This is a log message');
 * logger.error('This is an error message');
 * @ignore
 */
export type Logger = {
  /** Log general messages */
  log: (payload: string) => void;
  /** Log error messages */
  error: (payload: string) => void;
  /** Log warning messages */
  warn: (payload: string) => void;
  /** Log informational messages */
  info: (payload: string) => void;
  /** Log detailed trace messages */
  trace: (payload: string) => void;
  /** Log debug messages */
  debug: (payload: string) => void;
};

/**
 * Contextual information for log entries.
 * @public
 * @ignore
 */
export interface LogContext {
  /** Module name where the log originated */
  module?: string;
  /** Method name where the log originated */
  method?: string;
  interactionId?: string;
  trackingId?: string;
  /** Additional structured data to include in logs */
  data?: Record<string, any>;
  /** Error object to include in logs */
  error?: Error | unknown;
}

/**
 * Available logging severity levels.
 * @enum {string}
 * @public
 * @example
 * const level: LOGGING_LEVEL = LOGGING_LEVEL.error;
 * @ignore
 */
export enum LOGGING_LEVEL {
  /** Critical failures that require immediate attention */
  error = 'ERROR',
  /** Important issues that don't prevent the system from working */
  warn = 'WARN',
  /** General informational logs */
  log = 'LOG',
  /** Detailed information about system operation */
  info = 'INFO',
  /** Highly detailed diagnostic information */
  trace = 'TRACE',
}

/**
 * Metadata for log uploads.
 * @public
 * @example
 * const meta: LogsMetaData = { feedbackId: 'fb123', correlationId: 'corr456' };
 * @ignore
 */
export type LogsMetaData = {
  /** Optional feedback ID to associate with logs */
  feedbackId?: string;
  /** Optional correlation ID to track related operations */
  correlationId?: string;
};

/**
 * Response from uploading logs to the server.
 * @public
 * @example
 * const response: UploadLogsResponse = { trackingid: 'track123', url: 'https://...', userId: 'user1' };
 */
export type UploadLogsResponse = {
  /** Tracking ID for the upload request */
  trackingid?: string;
  /** URL where the logs can be accessed */
  url?: string;
  /** ID of the user who uploaded logs */
  userId?: string;
  /** Feedback ID associated with the logs */
  feedbackId?: string;
  /** Correlation ID for tracking related operations */
  correlationId?: string;
};

/**
 * Internal Webex SDK interfaces needed for plugin integration.
 * @internal
 * @ignore
 */
interface IWebexInternal {
  /** Mercury service for real-time messaging */
  mercury: {
    /** Register an event listener */
    on: Listener;
    /** Remove an event listener */
    off: ListenerOff;
    /** Establish a connection to the Mercury service */
    connect: () => Promise<void>;
    /** Disconnect from the Mercury service */
    disconnect: () => Promise<void>;
    /** Whether Mercury is currently connected */
    connected: boolean;
    /** Whether Mercury is in the process of connecting */
    connecting: boolean;
  };
  /** Device information */
  device: {
    /** Current WDM URL */
    url: string;
    /** Current user's ID */
    userId: string;
    /** Current organization ID */
    orgId: string;
    /** Device version */
    version: string;
    /** Calling behavior configuration */
    callingBehavior: string;
    /** Whether the device is registered with WDM */
    registered?: boolean;
    /** Register the device with WDM */
    register?: () => Promise<void>;
    /** Unregister the device from WDM */
    unregister?: () => Promise<void>;
  };
  /** Presence service */
  presence: unknown;
  /** Services discovery and management */
  services: {
    /** Get a service URL by name */
    get: (service: string) => string;
    /** Wait for service catalog to be loaded */
    waitForCatalog: (service: string) => Promise<void>;
    /** Check if current environment is INT (integration) */
    isIntegrationEnvironment: () => boolean;
    /** Host catalog for service discovery */
    _hostCatalog: Record<string, ServiceHost[]>;
    /** Service URLs cache */
    _serviceUrls: {
      /** Mobius calling service */
      mobius: string;
      /** Identity service */
      identity: string;
      /** Janus media server */
      janus: string;
      /** WDM (WebEx Device Management) service */
      wdm: string;
      /** BroadWorks IDP proxy service */
      broadworksIdpProxy: string;
      /** Hydra API service */
      hydra: string;
      /** Mercury API service */
      mercuryApi: string;
      /** UC Management gateway service */
      'ucmgmt-gateway': string;
      /** Contacts service */
      contactsService: string;
    };
  };
  /** Metrics collection services */
  newMetrics: {
    /** Submit behavioral events (user actions) */
    submitBehavioralEvent: SubmitBehavioralEvent;
    /** Submit operational events (system operations) */
    submitOperationalEvent: SubmitOperationalEvent;
    /** Submit business events (business outcomes) */
    submitBusinessEvent: SubmitBusinessEvent;
  };
  /** Support functionality */
  support: {
    /** Submit logs to server */
    submitLogs: (
      metaData: LogsMetaData,
      logs: string,
      options: {
        /** Whether to submit full logs or just differences */
        type: 'diff' | 'full';
      }
    ) => Promise<UploadLogsResponse>;
  };
}

/**
 * Interface representing the WebexSDK core functionality.
 * @interface WebexSDK
 * @public
 * @example
 * const sdk: WebexSDK = ...;
 * sdk.request({ service: 'identity', resource: '/users', method: HTTP_METHODS.GET });
 * @ignore
 */
export interface WebexSDK {
  /** Version of the WebexSDK */
  version: string;
  /** Whether the SDK can authorize requests */
  canAuthorize: boolean;
  /** Credentials management */
  credentials: {
    /** Get the user token for authentication */
    getUserToken: () => Promise<string>;
    /** Get the organization ID */
    getOrgId: () => string;
  };
  /** Whether the SDK is ready for use */
  ready: boolean;
  /** Make a request to the Webex APIs */
  request: <T>(payload: WebexRequestPayload) => Promise<T>;
  /** Register a one-time event handler */
  once: (event: string, callBack: () => void) => void;
  /** Internal plugins and services */
  internal: IWebexInternal;
  /** Logger instance */
  logger: Logger;
}

/**
 * An interface for the `ContactCenter` class.
 * The `ContactCenter` package is designed to provide a set of APIs to perform various operations for the Agent flow within Webex Contact Center.
 * @public
 * @example
 * const cc: IContactCenter = ...;
 * cc.register().then(profile => { ... });
 * @ignore
 */
export interface IContactCenter {
  /**
   * Initialize the CC SDK by setting up the contact center mercury connection.
   * This establishes WebSocket connectivity for real-time communication.
   *
   * @returns A Promise that resolves to the agent's profile upon successful registration
   * @public
   * @example
   * cc.register().then(profile => { ... });
   */
  register(): Promise<Profile>;

  /** Returns the system-managed WellbeingBreak idle code for the registered session. */
  getWellbeingBreakIdleCode(): Promise<Entity>;
}

/**
 * Generic HTTP response structure.
 * @public
 * @example
 * const response: IHttpResponse = { body: {}, statusCode: 200, method: 'GET', headers: {}, url: '...' };
 * @ignore
 */
export interface IHttpResponse {
  /** Response body content */
  body: any;
  /** HTTP status code */
  statusCode: number;
  /** HTTP method used for the request */
  method: string;
  /** Response headers */
  headers: Headers;
  /** Request URL */
  url: string;
}

/**
 * Supported login options for agent authentication.
 * @public
 * @example
 * const option: LoginOption = LoginOption.AGENT_DN;
 * @ignore
 */
export const LoginOption = {
  /** Login using agent's direct number */
  AGENT_DN: 'AGENT_DN',
  /** Login using an extension number */
  EXTENSION: 'EXTENSION',
  /** Login using browser WebRTC capabilities */
  BROWSER: 'BROWSER',
} as const;

/**
 * Union type of login options.
 * @public
 * @example
 * function login(option: LoginOption) { ... }
 * @ignore
 */
export type LoginOption = Enum<typeof LoginOption>;

/**
 * Request payload for subscribing to the contact center websocket.
 * @public
 * @example
 * const req: SubscribeRequest = { force: true, isKeepAliveEnabled: true, clientType: 'browser', allowMultiLogin: false };
 * @ignore
 */
export type SubscribeRequest = {
  /** Whether to force connection even if another exists */
  force: boolean;
  /** Whether to send keepalive messages */
  isKeepAliveEnabled: boolean;
  /** Type of client connecting */
  clientType: string;
  /** Whether to allow login from multiple devices */
  allowMultiLogin: boolean;
};

/**
 * Represents the response from getListOfTeams method.
 * Teams are groups of agents that can be managed together.
 * @public
 * @example
 * const team: Team = { id: 'team1', name: 'Support', desktopLayoutId: 'layout1' };
 * @ignore
 */
export type Team = {
  /**
   * Unique identifier of the team.
   */
  id: string;

  /**
   * Display name of the team.
   */
  name: string;

  /**
   * Associated desktop layout ID for the team.
   * Controls how the agent desktop is displayed for team members.
   */
  desktopLayoutId?: string;
};

/**
 * Represents the request to perform agent login.
 * @public
 * @example
 * const login: AgentLogin = { dialNumber: '1234', teamId: 'team1', loginOption: LoginOption.AGENT_DN };
 */
export type AgentLogin = {
  /**
   * A dialNumber field contains the number to dial such as a route point or extension.
   * Required for AGENT_DN and EXTENSION login options.
   */
  dialNumber?: string;

  /**
   * The unique ID representing a team of users.
   * The agent must belong to this team.
   */
  teamId: string;

  /**
   * The loginOption field specifies the type of login method.
   * Controls how calls are delivered to the agent.
   */
  loginOption: LoginOption;
};

/**
 * Represents the request to update agent profile settings.
 * @public
 * @example
 * const update: AgentProfileUpdate = { loginOption: LoginOption.BROWSER, dialNumber: '5678' };
 */
export type AgentProfileUpdate = Pick<AgentLogin, 'loginOption' | 'dialNumber' | 'teamId'>;

/**
 * Union type for all possible request body types.
 * @internal
 * @ignore
 */
export type RequestBody =
  | SubscribeRequest
  | Agent.Logout
  | Agent.UserStationLogin
  | Agent.StateChange
  | Agent.BuddyAgents
  | Contact.HoldResumePayload
  | Contact.ResumeRecordingPayload
  | Contact.ConsultPayload
  | Contact.ConsultEndAPIPayload // API Payload accepts only QueueId wheres SDK API allows more params
  | Contact.TransferPayLoad
  | Contact.ConsultTransferPayLoad
  | Contact.cancelCtq
  | Contact.WrapupPayLoad
  | Contact.DialerPayload
  | Contact.PreviewContactPayload
  | CreateUserPreferenceRequest
  | UpdateUserPreferenceRequest;

/**
 * Represents the options to fetch buddy agents for the logged in agent.
 * Buddy agents are other agents who can be consulted or transferred to.
 * @public
 * @example
 * const opts: BuddyAgents = { mediaType: 'telephony', state: 'Available' };
 */
export type BuddyAgents = {
  /**
   * The media type channel to filter buddy agents. Defaults to telephony when omitted.
   */
  mediaType?: 'telephony' | 'chat' | 'social' | 'email';

  /**
   * Optional filter for agent state.
   * If specified, returns only agents in that state.
   * If omitted, returns both available and idle agents.
   */
  state?: 'Available' | 'Idle';

  /**
   * Applies the default state policy for the operation. An explicit state takes precedence.
   */
  action?: 'Consult' | 'Transfer';
};

/**
 * Holds the configuration flags for the Agent.
 * These flags determine the availability of certain features in the Agent UI.
 * @internal
 */
export type ConfigFlags = {
  isEndTaskEnabled: boolean;
  isEndConsultEnabled: boolean;
  webRtcEnabled: boolean;
  autoWrapup: boolean;
  aiFeature?: AIFeatureFlags;
  /** Agent-profile policy used to derive task consult/transfer destination controls. */
  consultTransfer?: Contact.ConsultTransferDestinationConfig;
  /**
   * Optional toggle to globally enable/disable recording controls.
   * Falls back to backend hints when omitted.
   */
  isRecordingEnabled?: boolean;
  /** Whether wxApp thick-client answer controls/APIs are enabled (WXCC-6026) */
  enableWxBetterTogether?: boolean;
};

/**

 * Generic error structure for Contact Center SDK errors.
 * Contains detailed information about the error context.
 * @public
 * @example
 * const err: GenericError = new Error('Failed');
 * err.details = { type: 'ERR', orgId: 'org1', trackingId: 'track1', data: {} };
 * @ignore
 */
export interface GenericError extends Error {
  /** Structured details about the error */
  details: {
    /** Error type identifier */
    type: string;
    /** Organization ID where the error occurred */
    orgId: string;
    /** Unique tracking ID for the error */
    trackingId: string;
    /** Additional error context data */
    data: Record<string, any>;
  };
}

/**
 * Response type for station login operations.
 * Either a success response with agent details or an error.
 * @public
 * @example
 * function handleLogin(resp: StationLoginResponse) { ... }
 */
export type StationLoginResponse = Agent.StationLoginSuccessResponse | Error;

/**
 * Response type for station logout operations.
 * Either a success response with logout details or an error.
 * @public
 * @example
 * function handleLogout(resp: StationLogoutResponse) { ... }
 */
export type StationLogoutResponse = Agent.LogoutSuccess | Error;

/**
 * Response type for station relogin operations.
 * Either a success response with relogin details or an error.
 * @public
 * @example
 * function handleReLogin(resp: StationReLoginResponse) { ... }
 * @ignore
 */
export type StationReLoginResponse = Agent.ReloginSuccess | Error;

/**
 * Response type for agent state change operations.
 * Either a success response with state change details or an error.
 * @public
 * @example
 * function handleStateChange(resp: SetStateResponse) { ... }
 * @ignore
 */
export type SetStateResponse = Agent.StateChangeSuccess | Error;

/**
 * AddressBook types
 */
export interface AddressBookEntry {
  id: string;
  organizationId?: string;
  version?: number;
  name: string;
  number: string;
  createdTime?: number;
  lastUpdatedTime?: number;
}

export type AddressBookEntriesResponse = PaginatedResponse<AddressBookEntry>;

export interface AddressBookEntrySearchParams extends BaseSearchParams {
  addressBookId?: string;
}

/**
 * EntryPointRecord types
 */
export interface EntryPointRecord {
  id: string;
  name: string;
  /** Dialled number mapped to this entry point when included in the list response. */
  number?: string;
  description?: string;
  type?: string;
  isActive?: boolean;
  orgId?: string;
  createdAt?: string;
  updatedAt?: string;
  settings?: Record<string, any>;
}

export type EntryPointListResponse = PaginatedResponse<EntryPointRecord>;
export type EntryPointSearchParams = BaseSearchParams;

/**
 * Queue types
 */
export interface QueueSkillRequirement {
  organizationId?: string;
  id?: string;
  version?: number;
  skillId: string;
  skillName?: string;
  skillType?: string;
  condition: string;
  skillValue: string;
  createdTime?: number;
  lastUpdatedTime?: number;
}

export interface QueueAgent {
  id: string;
  ciUserId?: string;
}

export interface AgentGroup {
  teamId: string;
}

export interface CallDistributionGroup {
  agentGroups: AgentGroup[];
  order: number;
  duration?: number;
}

export interface AssistantSkillMapping {
  assistantSkillId?: string;
  assistantSkillUpdatedTime?: number;
}

/**
 * Configuration for a contact service queue
 * @public
 */
export interface ContactServiceQueue {
  /** Organization ID */
  organizationId?: string;
  /** Unique identifier for the queue */
  id?: string;
  /** Version of the queue */
  version?: number;
  /** Name of the Contact Service Queue */
  name: string;
  /** Description of the queue */
  description?: string;
  /** Queue type (INBOUND, OUTBOUND) */
  queueType: 'INBOUND' | 'OUTBOUND';
  /** Whether to check agent availability */
  checkAgentAvailability: boolean;
  /** Channel type (TELEPHONY, EMAIL, SOCIAL_CHANNEL, CHAT, etc.) */
  channelType: 'TELEPHONY' | 'EMAIL' | 'FAX' | 'CHAT' | 'VIDEO' | 'OTHERS' | 'SOCIAL_CHANNEL';
  /** Social channel type for SOCIAL_CHANNEL channelType */
  socialChannelType?:
    | 'MESSAGEBIRD'
    | 'MESSENGER'
    | 'WHATSAPP'
    | 'APPLE_BUSINESS_CHAT'
    | 'GOOGLE_BUSINESS_MESSAGES';
  /** Service level threshold in seconds */
  serviceLevelThreshold: number;
  /** Maximum number of simultaneous contacts */
  maxActiveContacts: number;
  /** Maximum time in queue in seconds */
  maxTimeInQueue: number;
  /** Default music in queue media file ID */
  defaultMusicInQueueMediaFileId: string;
  /** Timezone for routing strategies */
  timezone?: string;
  /** Whether the queue is active */
  active: boolean;
  /** Whether outdial campaign is enabled */
  outdialCampaignEnabled?: boolean;
  /** Whether monitoring is permitted */
  monitoringPermitted: boolean;
  /** Whether parking is permitted */
  parkingPermitted: boolean;
  /** Whether recording is permitted */
  recordingPermitted: boolean;
  /** Whether recording all calls is permitted */
  recordingAllCallsPermitted: boolean;
  /** Whether pausing recording is permitted */
  pauseRecordingPermitted: boolean;
  /** Recording pause duration in seconds */
  recordingPauseDuration?: number;
  /** Control flow script URL */
  controlFlowScriptUrl: string;
  /** IVR requeue URL */
  ivrRequeueUrl: string;
  /** Overflow number for telephony */
  overflowNumber?: string;
  /** Vendor ID */
  vendorId?: string;
  /** Routing type */
  routingType: 'LONGEST_AVAILABLE_AGENT' | 'SKILLS_BASED' | 'CIRCULAR' | 'LINEAR';
  /** Skills-based routing type */
  skillBasedRoutingType?: 'LONGEST_AVAILABLE_AGENT' | 'BEST_AVAILABLE_AGENT';
  /** Queue routing type */
  queueRoutingType: 'TEAM_BASED' | 'SKILL_BASED' | 'AGENT_BASED';
  /** Queue skill requirements */
  queueSkillRequirements?: QueueSkillRequirement[];
  /** List of agents for agent-based queue */
  agents?: QueueAgent[];
  /** Call distribution groups */
  callDistributionGroups: CallDistributionGroup[];
  /** XSP version */
  xspVersion?: string;
  /** Subscription ID */
  subscriptionId?: string;
  /** Assistant skill mapping */
  assistantSkill?: AssistantSkillMapping;
  /** Whether this is a system default queue */
  systemDefault?: boolean;
  /** User who last updated agents list */
  agentsLastUpdatedByUserName?: string;
  /** Email of user who last updated agents list */
  agentsLastUpdatedByUserEmailPrefix?: string;
  /** When agents list was last updated */
  agentsLastUpdatedTime?: number;
  /** Creation timestamp in epoch millis */
  createdTime?: number;
  /** Last updated timestamp in epoch millis */
  lastUpdatedTime?: number;
}

export type ContactServiceQueuesResponse = PaginatedResponse<ContactServiceQueue>;

export interface ContactServiceQueueSearchParams extends BaseSearchParams {
  desktopProfileFilter?: boolean;
  provisioningView?: boolean;
  singleObjectResponse?: boolean;
}

/**
 * Response type for buddy agents query operations.
 * Either a success response with list of buddy agents or an error.
 * @public
 * @example
 * function handleBuddyAgents(resp: BuddyAgentsResponse) { ... }
 */
export type BuddyAgentsResponse = Agent.BuddyAgentsSuccess | Error;

/**
 * Response type for device type update operations.
 * Either a success response with update confirmation or an error.
 * @public
 * @example
 * function handleUpdateDeviceType(resp: UpdateDeviceTypeResponse) { ... }
 */
export type UpdateDeviceTypeResponse = Agent.DeviceTypeUpdateSuccess | Error;

/**
 * Supported transcript control actions for AI Assistant events.
 * @public
 * @example
 * const action: TranscriptAction = 'START';
 * @ignore
 */
export type TranscriptAction = 'START' | 'STOP';

/**
 * Parameters used to request AI Assistant real-time assistance.
 * @public
 * @example
 * const params: RealTimeAssistanceParams = {
 *   interactionId: 'interaction-123',
 *   context: 'Need help with credit card payment due date',
 * };
 */
export type RealTimeAssistanceParams = {
  /** Agent identifier */
  agentId: string;
  /** Interaction identifier for which assistance should be generated */
  interactionId: string;
  /** Optional additional context that should refine the assistance */
  context?: string;
  /** Optional language code for assistance (for example, 'en'). Defaults to 'en'. */
  languageCode?: string;
};

/**
 * Supported user actions on an AI Assistant real-time assistance adaptive card.
 * @public
 */
export const RealTimeAssistanceUserActionId = {
  /** User liked the real-time assistance response */
  LIKE: 'likeButton',
  /** User disliked the real-time assistance response */
  DISLIKE: 'dislikeButton',
  /** User copied the real-time assistance response */
  COPY: 'copyButton',
} as const;

/**
 * Union type of supported real-time assistance user actions.
 * @public
 */
export type RealTimeAssistanceUserActionId = Enum<typeof RealTimeAssistanceUserActionId>;

/**
 * Parameters used to send user action feedback for a real-time assistance adaptive card.
 * @public
 * @example
 * const params: RealTimeAssistanceUserActionParams = {
 *   agentId: 'agent-123',
 *   interactionId: 'interaction-123',
 *   adaptiveCardId: 'adaptive-card-123',
 *   actionId: RealTimeAssistanceUserActionId.LIKE,
 * };
 */
export type RealTimeAssistanceUserActionParams = {
  /** Agent identifier */
  agentId: string;
  /** Interaction identifier associated with the real-time assistance response */
  interactionId: string;
  /** Adaptive card identifier from the real-time assistance payload */
  adaptiveCardId: string;
  /** User action performed on the adaptive card */
  actionId: RealTimeAssistanceUserActionId;
  /** Optional language code. Defaults to 'en'. */
  languageCode?: string;
};

/**
 * Wellness notification actions delivered by the Contact Center notification service.
 * @public
 */
export const WELLNESS_BREAK_NOTIFICATION_ACTIONS = {
  PROVIDE_WELLNESS_BREAK: 'PROVIDE_WELLNESS_BREAK',
  SUGGEST_WELLNESS_BREAK: 'SUGGEST_WELLNESS_BREAK',
  WELLNESS_BREAK_NOT_ALLOWED: 'WELLNESS_BREAK_NOT_ALLOWED',
} as const;

/** Union of supported wellness notification actions. @public */
export type WellnessBreakNotificationAction = Enum<typeof WELLNESS_BREAK_NOTIFICATION_ACTIONS>;

/**
 * Agent actions accepted by the wellness action API.
 * @public
 */
export const WELLNESS_BREAK_USER_ACTIONS = {
  REQUESTED: 'REQUESTED',
  ACCEPTED: 'ACCEPTED',
  REJECTED: 'REJECTED',
  NO_RESPONSE: 'NO_RESPONSE',
} as const;

/** Union of supported wellness action API values. @public */
export type WellnessBreakUserAction = Enum<typeof WELLNESS_BREAK_USER_ACTIONS>;

/**
 * Validated, agent-scoped wellness notification emitted by Contact Center.
 * @public
 */
export interface WellnessBreakEvent {
  /** Agent identifier */
  agentId: string;
  /** Organization identifier */
  orgId: string;
  /** Session identifier supplied by the notification; it may differ from the consumer's active session */
  agentSessionId: string;
  /** Backend wellness action */
  actionEvent: WellnessBreakNotificationAction;
  /** Optional untrusted plain-text message supplied by the backend */
  actionText?: string;
  /** Optional normalized interaction diagnostic */
  interactionId?: string;
  /** Notification diagnostic only; never an action-request correlation identifier */
  trackingId?: string;
}

/**
 * Parameters for responding to a backend-provided wellness offer.
 * @public
 */
export interface RespondToWellnessBreakParams {
  /** Agent response; REQUESTED is available only through requestWellnessBreak */
  action: Exclude<WellnessBreakUserAction, typeof WELLNESS_BREAK_USER_ACTIONS.REQUESTED>;
}

/**
 * Supported AI Assistant event categories.
 * @public
 * @example
 * const eventType: AIAssistantEventType = AIAssistantEventType.CUSTOM_EVENT;
 * @ignore
 */
export const AIAssistantEventType = {
  /** Custom AI Assistant event */
  CUSTOM_EVENT: 'CUSTOM_EVENT',
  /** CTI-backed AI Assistant event */
  CTI_EVENT: 'CTI_EVENT',
} as const;

/**
 * Union type of AI Assistant event categories.
 * @public
 * @example
 * function send(type: AIAssistantEventType) { ... }
 * @ignore
 */
export type AIAssistantEventType = Enum<typeof AIAssistantEventType>;

/**
 * Supported AI Assistant event names.
 * @public
 * @example
 * const name: AIAssistantEventName = AIAssistantEventName.GET_TRANSCRIPTS;
 * @ignore
 */
export const AIAssistantEventName = {
  /** Request transcript streaming for an interaction */
  GET_TRANSCRIPTS: 'GET_TRANSCRIPTS',
  /** Request a suggested response for an interaction */
  GET_SUGGESTIONS: 'GET_SUGGESTIONS',
  /** Add extra context to refine a suggested response */
  ADD_SUGGESTIONS_EXTRA_CONTEXT: 'ADD_SUGGESTIONS_EXTRA_CONTEXT',
  /** Request post-call summary generation */
  GET_POST_CALL_SUMMARY: 'GET_POST_CALL_SUMMARY',
  /** Request consult mid-call summary generation */
  GET_MID_CALL_CONSULT_SUMMARY: 'GET_MID_CALL_CONSULT_SUMMARY',
  /** Request transfer mid-call summary generation */
  GET_MID_CALL_TRANSFER_SUMMARY: 'GET_MID_CALL_TRANSFER_SUMMARY',
  /** Post-call summary response event */
  POST_CALL_SUMMARY_RESPONSE: 'POST_CALL_SUMMARY_RESPONSE',
  /** Consult mid-call summary response event */
  MID_CALL_CONSULT_SUMMARY_RESPONSE: 'MID_CALL_CONSULT_SUMMARY_RESPONSE',
  /** Transfer mid-call summary response event */
  MID_CALL_TRANSFER_SUMMARY_RESPONSE: 'MID_CALL_TRANSFER_SUMMARY_RESPONSE',
  /** Suggested digital response event */
  SUGGESTED_RESPONSES_DIGITAL: 'SUGGESTED_RESPONSES_DIGITAL',
  /** User action on a suggested response adaptive card */
  SUGGESTED_RESPONSES_USER_ACTION: 'SUGGESTED_RESPONSES_USER_ACTION',
  /** Agent Wellness Break request/response action */
  WELLNESS_BREAK_ACTION: 'WellnessBreakAction',
} as const;

/**
 * Union type of AI Assistant event names.
 * @public
 * @example
 * function handle(name: AIAssistantEventName) { ... }
 * @ignore
 */
export type AIAssistantEventName = Enum<typeof AIAssistantEventName>;

/**
 * A single transcript message entry returned by AI Assistant APIs.
 * @public
 * @example
 * const message: TranscriptMessage = { role: 'AGENT', content: 'Hello', messageId: '1', publishTimestamp: Date.now() };
 *
 */
export type TranscriptMessage = {
  /** Speaker role for this message */
  role: string;
  /** Transcript chunk content */
  content: string;
  /** Unique message identifier */
  messageId: string;
  /** Message publish timestamp (epoch milliseconds) */
  publishTimestamp: number;
};

/**
 * Response payload for historic transcripts API.
 * @public
 * @example
 * const resp: HistoricTranscriptsResponse = { orgId: 'org', agentId: 'agent', conversationId: null, interactionId: 'int', source: 'AI', data: [] };
 *
 */
export type HistoricTranscriptsResponse = {
  /** Organization identifier */
  orgId: string;
  /** Agent identifier */
  agentId: string;
  /** Conversation identifier when available */
  conversationId: string | null;
  /** Interaction identifier */
  interactionId: string;
  /** Data source identifier */
  source: string;
  /** Transcript messages */
  data: TranscriptMessage[];
};

import {createActor} from 'xstate';
import {
  createTaskStateMachine,
  TaskEvent,
  TaskState,
} from '../../../../../../src/services/task/state-machine';
import {createTaskData} from '../taskTestUtils';
import {guards} from '../../../../../../src/services/task/state-machine/guards';

const createConfig = () => ({
  channelType: 'voice' as const,
  isEndTaskEnabled: true,
  isEndConsultEnabled: true,
  voiceVariant: 'pstn' as const,
  isRecordingEnabled: true,
});

/** Mirrors Task.emitTaskWrapup: publishWrapup spy only runs when context would emit task:wrapup. */
function createPublishAwareEmitTaskWrapupMock() {
  const publishWrapup = jest.fn();
  const emitTaskWrapup = ({context}: {context: {taskData?: {wrapUpRequired?: boolean}}}) => {
    if (context.taskData?.wrapUpRequired) {
      publishWrapup();
    }
  };

  return {emitTaskWrapup, publishWrapup};
}

describe('Task state machine', () => {
  const startMachine = () => {
    const actor = createActor(createTaskStateMachine(createConfig()));
    actor.start();

    return actor;
  };

  describe('recording state derivation', () => {
    it('captures recording flags from offer payload', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          callProcessingDetails: {
            recordInProgress: true,
            isPaused: false,
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.context.recordingControlsAvailable).toBe(true);
      expect(snapshot.context.recordingInProgress).toBe(true);
    });

    it('updates recordingPaused when ASSIGN payload reports pause', () => {
      const service = startMachine();
      const initialTaskData = createTaskData();
      const pausedTaskData = createTaskData({
        interaction: {
          callProcessingDetails: {
            isPaused: true,
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: initialTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: pausedTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.context.recordingControlsAvailable).toBe(true);
      expect(snapshot.context.recordingInProgress).toBe(false);
    });

    it('updates recording state when recording started event arrives', () => {
      const service = startMachine();
      const initialTaskData = createTaskData();
      const recordingTaskData = createTaskData({
        interaction: {
          callProcessingDetails: {
            recordingStarted: true,
            recordInProgress: true,
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: initialTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: initialTaskData});
      service.send({type: TaskEvent.RECORDING_STARTED, taskData: recordingTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONNECTED);
      expect(snapshot.context.recordingControlsAvailable).toBe(true);
      expect(snapshot.context.recordingInProgress).toBe(true);
    });
  });

  describe('hold and resume flow', () => {
    it('moves through HOLD -> HELD -> CONNECTED on success events', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);

      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HOLD_INITIATING);

      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      service.send({type: TaskEvent.UNHOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.RESUME_INITIATING);

      service.send({type: TaskEvent.UNHOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });
  });

  describe('partial lifecycle payloads', () => {
    const createActiveMainCallTaskData = (isHold = false) =>
      createTaskData({
        agentId: 'agent-1',
        interactionId: 'interaction-1',
        mediaResourceId: 'main-media',
        interaction: {
          state: 'connected',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'main-media': {
              mediaResourceId: 'main-media',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold,
            },
          },
        } as any,
      });

    const createPartialMainCallTaskData = (isHold = false, omitSelf = false) =>
      createTaskData({
        agentId: 'agent-1',
        interactionId: 'interaction-1',
        mediaResourceId: 'main-media',
        interaction: {
          state: 'connected',
          participants: omitSelf
            ? {'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false}}
            : {
                'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
                'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
              },
          media: {
            'main-media': {
              mediaResourceId: 'main-media',
              mType: 'mainCall',
              participants: ['customer-1'],
              isHold,
            },
          },
        } as any,
      });

    const startMachineWithEndSpy = () => {
      const emitTaskEnd = jest.fn();
      const service = createActor(
        createTaskStateMachine({...createConfig(), agentId: 'agent-1'}, {actions: {emitTaskEnd}})
      );
      service.start();

      return {service, emitTaskEnd};
    };

    const enterTransientHoldState = (
      service: ReturnType<typeof startMachine>,
      state: TaskState.HOLD_INITIATING | TaskState.RESUME_INITIATING,
      taskData: ReturnType<typeof createActiveMainCallTaskData>
    ) => {
      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: 'main-media'});

      if (state === TaskState.RESUME_INITIATING) {
        service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: 'main-media'});
        service.send({type: TaskEvent.UNHOLD_INITIATED, mediaResourceId: 'main-media'});
      }

      expect(service.getSnapshot().value).toBe(state);
    };

    it('keeps CONNECTED when another participant leave event has a partial mainCall', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: createPartialMainCallTaskData(false, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });

    it('ignores PARTICIPANT_LEAVE in CONNECTED even when it identifies the current agent', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: createPartialMainCallTaskData(false, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });

    it('enters WRAPPING_UP on TASK_WRAPUP while HOLD_INITIATING and emits wrap-up once', () => {
      const emitTaskWrapup = jest.fn();
      const service = createActor(
        createTaskStateMachine({...createConfig(), agentId: 'agent-1'}, {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createActiveMainCallTaskData();

      enterTransientHoldState(service, TaskState.HOLD_INITIATING, taskData);
      service.send({
        type: TaskEvent.TASK_WRAPUP,
        taskData: {...taskData, wrapUpRequired: true},
      });

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(emitTaskWrapup).toHaveBeenCalledTimes(1);
    });

    it('ignores PARTICIPANT_LEAVE in HOLD_INITIATING when a remote Drop identifies the current agent', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData();

      enterTransientHoldState(service, TaskState.HOLD_INITIATING, taskData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: createPartialMainCallTaskData(false, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.HOLD_INITIATING);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });

    it('terminates RESUME_INITIATING when a remote Drop identifies the current agent', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData(true);

      enterTransientHoldState(service, TaskState.RESUME_INITIATING, taskData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: createPartialMainCallTaskData(true, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(emitTaskEnd).toHaveBeenCalledTimes(1);
    });

    it('keeps HOLD_INITIATING when ParticipantLeftConference identifies another participant', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData();

      enterTransientHoldState(service, TaskState.HOLD_INITIATING, taskData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: createPartialMainCallTaskData(false, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.HOLD_INITIATING);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });

    it('terminates RESUME_INITIATING when another participant leave omits self from the roster', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData(true);

      enterTransientHoldState(service, TaskState.RESUME_INITIATING, taskData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: createPartialMainCallTaskData(true, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(emitTaskEnd).toHaveBeenCalledTimes(1);
    });

    it('terminates HELD when another participant leave event omits self from its roster', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData(true);

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: 'main-media'});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: 'main-media'});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: createPartialMainCallTaskData(true, true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(emitTaskEnd).toHaveBeenCalledTimes(1);
    });

    it('keeps HELD when CONSULT_END has a partial mainCall', () => {
      const {service, emitTaskEnd} = startMachineWithEndSpy();
      const taskData = createActiveMainCallTaskData(true);

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: 'main-media'});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: 'main-media'});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      service.send({
        type: TaskEvent.CONSULT_END,
        taskData: createPartialMainCallTaskData(true),
      });

      expect(service.getSnapshot().value).toBe(TaskState.HELD);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });
  });

  describe('recording pause/resume events', () => {
    it('toggles recordingPaused flag based on events', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          callProcessingDetails: {recordInProgress: true},
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().context.recordingInProgress).toBe(true);

      service.send({type: TaskEvent.PAUSE_RECORDING});
      expect(service.getSnapshot().context.recordingInProgress).toBe(false);

      service.send({type: TaskEvent.RESUME_RECORDING});
      expect(service.getSnapshot().context.recordingInProgress).toBe(true);
    });

    it('toggles recording state while task is held', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          callProcessingDetails: {recordInProgress: true},
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);
      expect(service.getSnapshot().context.recordingInProgress).toBe(true);

      service.send({type: TaskEvent.PAUSE_RECORDING});
      expect(service.getSnapshot().context.recordingInProgress).toBe(false);

      service.send({type: TaskEvent.RESUME_RECORDING});
      expect(service.getSnapshot().context.recordingInProgress).toBe(true);
    });
  });

  describe('wrap-up and completion flow', () => {
    it('moves from CONNECTED -> WRAPPING_UP -> COMPLETED on END/WRAPUP_COMPLETE', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);

      service.send({type: TaskEvent.TASK_WRAPUP});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);

      service.send({type: TaskEvent.WRAPUP_COMPLETE});
      expect(service.getSnapshot().value).toBe(TaskState.COMPLETED);
    });

    it('handles CONTACT_ENDED by entering wrapping up before completion', () => {
      const service = startMachine();
      // Primary agent (isConsulted: false) should go to WRAPPING_UP
      const taskData = createTaskData({isConsulted: false} as any);

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});

      // CONTACT_ENDED event must include taskData for shouldWrapUpForThisAgent check
      service.send({type: TaskEvent.CONTACT_ENDED, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);

      service.send({type: TaskEvent.WRAPUP_COMPLETE});
      expect(service.getSnapshot().value).toBe(TaskState.COMPLETED);
    });

    it('emits task wrappedup before cleanup on COMPLETED entry', () => {
      const actionOrder: string[] = [];
      const actor = createActor(
        createTaskStateMachine(createConfig(), {
          actions: {
            emitTaskWrappedup: () => {
              actionOrder.push('emitTaskWrappedup');
            },
            cleanupResources: () => {
              actionOrder.push('cleanupResources');
            },
          },
        })
      );
      actor.start();
      const taskData = createTaskData();

      actor.send({type: TaskEvent.TASK_INCOMING, taskData});
      actor.send({type: TaskEvent.ASSIGN, taskData});
      actor.send({type: TaskEvent.TASK_WRAPUP});
      actor.send({type: TaskEvent.WRAPUP_COMPLETE});

      expect(actor.getSnapshot().value).toBe(TaskState.COMPLETED);
      expect(actionOrder).toEqual(['emitTaskWrappedup', 'cleanupResources']);
    });
  });

  describe('consult and conference flows', () => {
    const createSingleAgentConferenceTaskData = (interactionState: string, isHold = false) =>
      createTaskData({
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: interactionState,
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold,
            },
          },
        } as any,
      });

    const createConferenceConsultTaskData = ({
      interactionState,
      includeSecondAgent,
      conferenceHoldParticipant,
      isMainHeld = false,
    }: {
      interactionState: string;
      includeSecondAgent: boolean;
      conferenceHoldParticipant: boolean | string;
      isMainHeld?: boolean;
    }) =>
      createTaskData({
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: interactionState,
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          callProcessingDetails: {
            conferenceHoldParticipant,
          },
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
            },
            ...(includeSecondAgent
              ? {
                  'agent-2': {
                    id: 'agent-2',
                    pType: 'Agent',
                    hasLeft: false,
                  },
                }
              : {}),
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: includeSecondAgent
                ? ['agent-1', 'agent-2', 'customer-1']
                : ['agent-1', 'customer-1'],
              isHold: isMainHeld,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-3'],
              isHold: false,
            },
          },
        } as any,
      });

    it('boots from IDLE to CONSULTING on CONSULTING_ACTIVE for split-leg ordering', () => {
      const service = startMachine();
      const taskData = createTaskData({
        consultingAgentId: 'agent-1',
        isConsulted: false,
        interaction: {
          state: 'consulting',
        } as any,
      });

      expect(service.getSnapshot().value).toBe(TaskState.IDLE);
      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
        taskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(true);
    });

    it('hydrates to CONSULTING when top-level state is conference but self consultState is consulting', () => {
      const service = startMachine();
      const taskData = createTaskData({
        isConsulted: false,
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold: true,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.HYDRATE, taskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONSULTING);
      expect(snapshot.context.consultInitiator).toBe(true);
      expect(snapshot.context.consultFromConference).toBe(true);
    });

    it('hydrates consulted agent to CONSULTING when self consultState is consulting and main leg is held', () => {
      const service = startMachine();
      const taskData = createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold: true,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.HYDRATE, taskData});

      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
    });

    it('hydrates to CONSULTING when consult is pending (self consultState is consultInitiated)', () => {
      const service = startMachine();
      const taskData = createTaskData({
        isConsulted: false,
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultInitiated',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultReserved',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold: true,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.HYDRATE, taskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONSULTING);
      expect(snapshot.context.consultInitiator).toBe(true);
      expect(snapshot.context.consultFromConference).toBe(true);
    });

    it('tracks consult destination, agent join, and clears on consult end', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});

      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      expect(service.getSnapshot().context.consultInitiator).toBe(true);

      service.send({type: TaskEvent.CONSULT_SUCCESS});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
      });
      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(true);

      service.send({type: TaskEvent.CONSULT_END});
      const snapshotAfterEnd = service.getSnapshot();
      expect(snapshotAfterEnd.value).toBe(TaskState.HELD);
      expect(snapshotAfterEnd.context.consultDestinationAgentJoined).toBe(false);
    });

    it('returns to HELD with main-leg controls after AgentConsultEnded from Stable Prod while CONSULTING', () => {
      const service = startMachine();
      const baseTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: baseTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: baseTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-2',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS});
      service.send({type: TaskEvent.CONSULTING_ACTIVE, consultDestinationAgentJoined: true});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      const consultEndedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        type: 'AgentConsultEnded' as any,
        isConsulted: false,
        interaction: {
          state: 'connected',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.HELD);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.consultCallHeld).toBe(false);
      expect(snapshot.context.consultDestinationAgentJoined).toBe(false);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.consult.endConsult).toEqual({
        isVisible: false,
        isEnabled: false,
      });
      expect(snapshot.context.uiControls.main.hold).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.main.consult).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.main.transfer).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.main.recording).toEqual({
        isVisible: true,
        isEnabled: true,
      });
    });

    it('enables main consult after ending consult before consultee answers (CONSULT_INITIATING -> CONSULT_END)', () => {
      const service = startMachine();
      const baseTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: baseTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: baseTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-2',
        destinationType: 'agent',
      });
      // Consult requested but consultee (agent-2) has not answered yet.
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      // Agent 1 ends the consult before agent-2 answers. Backend AgentConsultEnded:
      // main on hold, self consultCompleted, no consult media, consultee not in participants.
      const consultEndedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        destAgentId: 'agent-2',
        destinationType: 'Agent',
        type: 'AgentConsultEnded' as any,
        isConsulted: false,
        interaction: {
          state: 'connected',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              hasJoined: true,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.HELD);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.consultDestinationAgentJoined).toBe(false);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.main.consult).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.consult.endConsult).toEqual({
        isVisible: false,
        isEnabled: false,
      });
    });

    it('stays HELD and clears consult UI when AgentConsultEnded arrives on HELD state', () => {
      const service = startMachine();
      const heldTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: 'hold',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: heldTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: heldTaskData});
      service.send({
        type: TaskEvent.HOLD_INITIATED,
        mediaResourceId: heldTaskData.mediaResourceId,
      });
      service.send({
        type: TaskEvent.HOLD_SUCCESS,
        mediaResourceId: heldTaskData.mediaResourceId,
        taskData: heldTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      const consultEndedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        type: 'AgentConsultEnded' as any,
        isConsulted: false,
        interaction: {
          state: 'hold',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.HELD);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.main.hold).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.consult.endConsult).toEqual({
        isVisible: false,
        isEnabled: false,
      });
    });

    it('keeps main.consult enabled on HELD after AgentConsultFailed then AgentConsultEnded (RONA)', () => {
      const service = startMachine();
      const heldTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        type: 'AgentContactHeld' as any,
        interaction: {
          state: 'hold',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          } as any,
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: heldTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: heldTaskData});
      service.send({
        type: TaskEvent.HOLD_INITIATED,
        mediaResourceId: heldTaskData.mediaResourceId,
      });
      service.send({
        type: TaskEvent.HOLD_SUCCESS,
        mediaResourceId: heldTaskData.mediaResourceId,
        taskData: heldTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      const consultCreatedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        consultingAgentId: 'agent-1',
        destAgentId: 'agent-2',
        isConsulted: false,
        type: 'AgentConsultCreated' as any,
        interaction: {
          state: 'consult',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultInitiated',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultReserved',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
            'consult-media': {
              mediaResourceId: 'consult-media',
              mType: 'consult',
              participants: ['agent-2', 'agent-1'],
            },
          } as any,
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_CREATED, taskData: consultCreatedTaskData});

      const consultFailedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        consultingAgentId: 'agent-1',
        destAgentId: 'agent-2',
        isConsulted: false,
        type: 'AgentConsultFailed' as any,
        interaction: {
          state: 'connected',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultReserved',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          } as any,
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_FAILED, taskData: consultFailedTaskData});

      const consultEndedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        isConsulted: false,
        type: 'AgentConsultEnded' as any,
        interaction: consultFailedTaskData.interaction,
      });
      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.HELD);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.main.consult).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.main.hold).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.main.transfer).toEqual({
        isVisible: true,
        isEnabled: true,
      });
    });

    it('returns to main leg (HELD) and does not clear the task after AgentConsultFailed then AgentConsultEnded while CONSULTING (RONA)', () => {
      const service = startMachine();
      const heldTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        type: 'AgentContactHeld' as any,
        interaction: {
          state: 'hold',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          } as any,
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: heldTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: heldTaskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: heldTaskData.mediaResourceId});
      service.send({
        type: TaskEvent.HOLD_SUCCESS,
        mediaResourceId: heldTaskData.mediaResourceId,
        taskData: heldTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      // Agent 1 initiates a consult and AgentConsulting arrives during ringing, moving the
      // initiator into CONSULTING before the consultee answers.
      service.send({type: TaskEvent.CONSULT, destination: 'agent-2', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultInitiator).toBe(true);

      // Consultee RONAs: AgentConsultFailed arrives while still in CONSULTING. Main stays held.
      const consultFailedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        consultingAgentId: 'agent-1',
        destAgentId: 'agent-2',
        isConsulted: false,
        type: 'AgentConsultFailed' as any,
        interaction: {
          state: 'consult',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              hasJoined: false,
              consultState: 'consultReserved',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
            'consult-media': {
              mediaResourceId: 'consult-media',
              mType: 'consult',
              participants: ['agent-2', 'agent-1'],
            },
          } as any,
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_FAILED, taskData: consultFailedTaskData});
      // The initiator must leave CONSULTING and fall back to the held main leg (not stay in
      // CONSULTING, which would let the trailing AgentConsultEnded terminate the task).
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      // AgentConsultEnded closes out the consult leg.
      const consultEndedTaskData = createTaskData({
        agentId: 'agent-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media',
        isConsulted: false,
        type: 'AgentConsultEnded' as any,
        interaction: {
          state: 'connected',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: 'agent-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultCompleted',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false, hasJoined: true},
          } as any,
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              isHold: true,
              participants: ['customer-1', 'agent-1'],
            },
          } as any,
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      const snapshot = service.getSnapshot();
      // The task must remain on the main leg (HELD) and never reach TERMINATED.
      expect(snapshot.value).toBe(TaskState.HELD);
      expect(snapshot.value).not.toBe(TaskState.TERMINATED);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.main.consult).toEqual({
        isVisible: true,
        isEnabled: true,
      });
    });

    it('transitions CONSULT_INITIATING to CONSULTING on CONSULTING_ACTIVE and marks destination joined', () => {
      const service = startMachine();
      const baseTaskData = createTaskData();
      const consultingTaskData = createTaskData({
        agentId: 'agent-1',
        isConsulted: false,
        consultMediaResourceId: 'consult-media',
        interaction: {
          state: 'consulting',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              hasJoined: true,
              consultState: 'consulting',
              isConsulted: true,
            },
          } as any,
          media: {
            'interaction-1': {mediaResourceId: 'interaction-1', mType: 'mainCall', isHold: true},
            'consult-media': {
              mediaResourceId: 'consult-media',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
            },
          } as any,
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: baseTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: baseTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-2',
        destinationType: 'agent',
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
        taskData: consultingTaskData,
      });

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONSULTING);
      expect(snapshot.context.consultInitiator).toBe(true);
      expect(snapshot.context.consultDestinationAgentJoined).toBe(true);
    });

    it('keeps consultDestinationAgentJoined false while consultee is only reserved, then sets true on actual join', () => {
      const service = startMachine();
      const pendingTaskData = createTaskData({
        isConsulted: false,
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consultInitiated',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              hasJoined: false,
              consultState: 'consultReserved',
              isConsulted: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold: true,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.HYDRATE, taskData: pendingTaskData});

      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(false);

      const joinedTaskData = {
        ...pendingTaskData,
        interaction: {
          ...pendingTaskData.interaction,
          participants: {
            ...pendingTaskData.interaction?.participants,
            'agent-2': {
              ...pendingTaskData.interaction?.participants?.['agent-2'],
              hasJoined: true,
              consultState: 'consulting',
            },
          },
        },
      } as any;

      service.send({type: TaskEvent.CONTACT_UPDATED, taskData: joinedTaskData});

      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(true);
    });

    it('hydrates conference consult context flags for active consult leg controls', () => {
      const service = startMachine();
      const taskData = createTaskData({
        type: 'AgentContactUnheld' as any,
        isConsulted: false,
        consultingAgentId: 'agent-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              hasJoined: true,
              consultState: 'consulting',
              isConsulted: true,
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
              isConsulted: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-3', 'customer-1'],
              isHold: false,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-2'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.HYDRATE, taskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONSULTING);
      expect(snapshot.context.consultInitiator).toBe(true);
      expect(snapshot.context.consultFromConference).toBe(true);
      expect(snapshot.context.consultDestinationAgentJoined).toBe(true);
      expect(snapshot.context.consultCallHeld).toBe(false);
    });

    it('returns to connected when consult ends after switching back to the main leg', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS});
      service.send({type: TaskEvent.SWITCH_TO_MAIN_CALL});

      expect(service.getSnapshot().context.consultCallHeld).toBe(true);

      service.send({type: TaskEvent.CONSULT_END});

      const snapshotAfterEnd = service.getSnapshot();
      expect(snapshotAfterEnd.value).toBe(TaskState.CONNECTED);
      expect(snapshotAfterEnd.context.consultCallHeld).toBe(false);
    });

    it('downgrades to HELD on CONSULT_END when conference has downgraded and conferenceHoldParticipant is true', () => {
      const service = startMachine();
      const conferenceTaskData = createConferenceConsultTaskData({
        interactionState: 'conference',
        includeSecondAgent: true,
        conferenceHoldParticipant: false,
      });
      const downgradedHeldTaskData = createConferenceConsultTaskData({
        interactionState: 'hold',
        includeSecondAgent: false,
        conferenceHoldParticipant: true,
        isMainHeld: true,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({type: TaskEvent.CONSULT_END, taskData: downgradedHeldTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);
    });

    it('downgrades to CONNECTED on CONSULT_END when conference has downgraded and conferenceHoldParticipant is false', () => {
      const service = startMachine();
      const conferenceTaskData = createConferenceConsultTaskData({
        interactionState: 'conference',
        includeSecondAgent: true,
        conferenceHoldParticipant: false,
      });
      const downgradedConnectedTaskData = createConferenceConsultTaskData({
        interactionState: 'connected',
        includeSecondAgent: false,
        conferenceHoldParticipant: false,
        isMainHeld: false,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({type: TaskEvent.CONSULT_END, taskData: downgradedConnectedTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('returns to CONFERENCING on CONSULT_END when conference is still active', () => {
      const service = startMachine();
      const conferenceTaskData = createConferenceConsultTaskData({
        interactionState: 'conference',
        includeSecondAgent: true,
        conferenceHoldParticipant: false,
      });
      const stillConferenceTaskData = createConferenceConsultTaskData({
        interactionState: 'conference',
        includeSecondAgent: true,
        conferenceHoldParticipant: false,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({type: TaskEvent.CONSULT_END, taskData: stillConferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    });

    it('transitions CONFERENCING to CONSULTING on CONSULTING_ACTIVE and marks DN consult joined', () => {
      const service = startMachine();
      const conferenceTaskData = createConferenceConsultTaskData({
        interactionState: 'conference',
        includeSecondAgent: true,
        conferenceHoldParticipant: false,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      const dnConsultTaskData = createTaskData({
        type: 'AgentConsulting' as any,
        agentId: 'agent-1',
        consultingAgentId: 'agent-1',
        isConsulted: false,
        destinationType: 'DN',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'dn-dest': {
              id: 'dn-dest',
              pType: 'DN',
              hasLeft: false,
              hasJoined: true,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: false,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'dn-dest'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
        taskData: dnConsultTaskData,
      });

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONSULTING);
      expect(snapshot.context.consultDestinationAgentJoined).toBe(true);
      expect(snapshot.context.consultFromConference).toBe(true);
      expect(snapshot.context.consultDestinationType).toBe('entryPoint');
    });

    it('transitions to conferencing when merge event is received', () => {
      const service = startMachine();
      const taskData = createTaskData({consultingAgentId: 'agent-1'});

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);

      service.send({type: TaskEvent.CONFERENCE_START});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    });

    it('sets hideBlindTransfer flag and clears consult context on EP-DN AgentConsultConferencing (CAI-8329)', () => {
      const service = startMachine();
      const agentId = 'agent-1';
      const consultMediaId = 'consult-media-1';
      const consultTaskData = createTaskData({
        agentId,
        consultingAgentId: agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        interaction: {
          state: 'consulting',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'consulting',
              isConsulted: false,
            },
            '+13159998087': {
              id: '+13159998087',
              pType: 'EP-DN',
              hasLeft: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasJoined: true, hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['customer-1', 'agent-1'],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998087', 'agent-1'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: consultTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: consultTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: '+13159998087',
        destinationType: 'entryPoint',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: consultTaskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);
      expect(service.getSnapshot().context.consultInitiator).toBe(true);

      const conferencingTaskData = createTaskData({
        agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        type: 'AgentConsultConferencing' as any,
        interaction: {
          state: 'conference',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'conferencing',
              isConsulted: false,
            },
            '+13159998087': {
              id: '+13159998087',
              pType: 'EP-DN',
              hasLeft: false,
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasJoined: true, hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['customer-1', 'agent-1'],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998087', 'agent-1'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferencingTaskData});

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONFERENCING);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.consultDestinationType).toBe(null);
      expect(snapshot.context.hideBlindTransferForEpDnPendingMerge).toBe(true);
      expect(snapshot.context.uiControls.activeLeg).toBe('main');
      expect(snapshot.context.uiControls.main.transfer).toEqual({
        isVisible: false,
        isEnabled: false,
      });
      expect(snapshot.context.uiControls.main.exitConference).toEqual({
        isVisible: true,
        isEnabled: true,
      });
      expect(snapshot.context.uiControls.consult.endConsult).toEqual({
        isVisible: false,
        isEnabled: false,
      });
    });

    it('terminates via wrapup when EXIT_CONFERENCE_SUCCESS is received in conferencing', () => {
      const service = startMachine();
      const taskData = createTaskData({
        // shouldWrapUpForThisAgent will return true when owner matches self agent
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
              isInPredial: false,
            },
            c1: {
              id: 'c1',
              pType: 'Customer',
              type: 'Customer',
              hasJoined: true,
              hasLeft: false,
              isInPredial: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              mediaMgr: 'mm',
              participants: ['agent-1', 'c1'],
              mType: 'mainCall',
              isHold: false,
              holdTimestamp: null,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.EXIT_CONFERENCE_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    const primeConferencing = (service: ReturnType<typeof startMachine>, taskData: ReturnType<typeof createTaskData>) => {
      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    };

    const conferenceInProgressTaskData = (overrides: Parameters<typeof createTaskData>[0] = {}) =>
      createTaskData({
        wrapUpRequired: true,
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              participants: ['agent-1', 'agent-2'],
              mType: 'mainCall',
              isHold: false,
            },
          },
        } as any,
        ...overrides,
      });

    const primeConnectedWithConferenceTaskData = (
      service: ReturnType<typeof startMachine>,
      taskData: ReturnType<typeof createTaskData>
    ) => {
      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    };

    it('enters WRAPPING_UP on EXIT_CONFERENCE_SUCCESS while CONNECTED with conference in task data', () => {
      const service = startMachine();
      const taskData = conferenceInProgressTaskData();

      primeConnectedWithConferenceTaskData(service, taskData);
      service.send({type: TaskEvent.EXIT_CONFERENCE_SUCCESS, taskData});

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(service.getSnapshot().context.taskData?.wrapUpRequired).toBe(true);
    });

    it('emits wrap-up once on EXIT_CONFERENCE_SUCCESS while CONNECTED', () => {
      const emitTaskWrapup = jest.fn();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = conferenceInProgressTaskData();

      primeConnectedWithConferenceTaskData(service, taskData);
      service.send({type: TaskEvent.EXIT_CONFERENCE_SUCCESS, taskData});

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(emitTaskWrapup).toHaveBeenCalledTimes(1);
    });

    it('terminates on EXIT_CONFERENCE_SUCCESS while CONNECTED when wrap-up is not required', () => {
      const service = startMachine();
      const taskData = conferenceInProgressTaskData({
        wrapUpRequired: false,
        interaction: {
          owner: 'other-agent',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
              isWrapUp: false,
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              participants: ['agent-1', 'agent-2'],
              mType: 'mainCall',
              isHold: false,
            },
          },
        } as any,
      });

      primeConnectedWithConferenceTaskData(service, taskData);
      service.send({type: TaskEvent.EXIT_CONFERENCE_SUCCESS, taskData});

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('does not re-emit wrap-up on late TASK_WRAPUP when wrap-up was already published', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = conferenceInProgressTaskData();

      primeConferencing(service, taskData);
      service.send({
        type: TaskEvent.EXIT_CONFERENCE_SUCCESS,
        taskData: {...taskData, wrapUpRequired: true},
      });
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(service.getSnapshot().context.taskData?.wrapUpRequired).toBe(true);

      const emitCountAfterExit = publishWrapup.mock.calls.length;
      service.send({
        type: TaskEvent.TASK_WRAPUP,
        taskData: {...taskData, wrapUpRequired: true},
      });

      expect(publishWrapup.mock.calls.length).toBe(emitCountAfterExit);
    });

    it('emits wrap-up on late TASK_WRAPUP when wrap-up was not yet published', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        wrapUpRequired: false,
        interaction: {
          owner: 'agent-1',
          state: 'connected',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.TASK_WRAPUP, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(service.getSnapshot().context.taskData?.wrapUpRequired).not.toBe(true);
      expect(publishWrapup).not.toHaveBeenCalled();

      service.send({
        type: TaskEvent.TASK_WRAPUP,
        taskData: {...taskData, wrapUpRequired: true},
      });

      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('terminates when EXIT_CONFERENCE_SUCCESS is received in conferencing and wrapup is not required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        isConsulted: true,
        wrapUpRequired: false,
        interaction: {
          owner: 'other-agent',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              hasJoined: true,
              hasLeft: false,
              isInPredial: false,
              isWrapUp: false,
            },
            c1: {
              id: 'c1',
              pType: 'Customer',
              type: 'Customer',
              hasJoined: true,
              hasLeft: false,
              isInPredial: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              mediaMgr: 'mm',
              participants: ['agent-1', 'c1'],
              mType: 'mainCall',
              isHold: false,
              holdTimestamp: null,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.EXIT_CONFERENCE_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('enters WRAPPING_UP on CONFERENCE_END when wrapUpRequired is stamped', () => {
      const service = startMachine();
      const taskData = createTaskData({
        wrapUpRequired: true,
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              isWrapUp: true,
              hasJoined: true,
              hasLeft: true,
            },
          },
        } as any,
      });

      primeConferencing(service, taskData);
      service.send({type: TaskEvent.CONFERENCE_END, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('emits wrap-up once on CONFERENCE_END when wrap-up is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        wrapUpRequired: true,
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              type: 'Agent',
              isWrapUp: true,
              hasJoined: true,
              hasLeft: true,
            },
          },
        } as any,
      });

      primeConferencing(service, taskData);
      service.send({type: TaskEvent.CONFERENCE_END, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('emits wrap-up once on TASK_WRAPUP from CONSULTING when wrap-up is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        interaction: {owner: 'agent-1', state: 'connected'} as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-2', destinationType: 'agent'});
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({
        type: TaskEvent.TASK_WRAPUP,
        taskData: {...taskData, wrapUpRequired: true},
      });
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('emits wrap-up once on TASK_WRAPUP from CONFERENCING when wrap-up is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
        } as any,
      });

      primeConferencing(service, taskData);
      service.send({
        type: TaskEvent.TASK_WRAPUP,
        taskData: {...taskData, wrapUpRequired: true},
      });
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('enters WRAPPING_UP on PARTICIPANT_LEAVE when this agent left and wrap-up is required', () => {
      const service = startMachine();
      const conferenceData = createTaskData({
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });
      const leaveData = createTaskData({
        wrapUpRequired: true,
        participantId: 'agent-1',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });

      primeConferencing(service, conferenceData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: leaveData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('emits wrap-up once on PARTICIPANT_LEAVE when wrap-up is required', () => {
      const emitTaskWrapup = jest.fn();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const conferenceData = createTaskData({
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });
      const leaveData = createTaskData({
        wrapUpRequired: true,
        participantId: 'agent-1',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });

      primeConferencing(service, conferenceData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: leaveData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(emitTaskWrapup).toHaveBeenCalledTimes(1);
    });

    it('does not wrap remaining agent on PARTICIPANT_LEAVE', () => {
      const service = startMachine();
      const conferenceData = createTaskData({
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            c1: {id: 'c1', pType: 'Customer', type: 'Customer', hasJoined: true, hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              mediaMgr: 'mm',
              participants: ['agent-1', 'agent-2', 'c1'],
              mType: 'mainCall',
              isHold: false,
              holdTimestamp: null,
            },
          },
        } as any,
      });
      const otherLeft = createTaskData({
        wrapUpRequired: false,
        participantId: 'agent-2',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            c1: {id: 'c1', pType: 'Customer', type: 'Customer', hasJoined: true, hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mediaType: 'telephony',
              mediaMgr: 'mm',
              participants: ['agent-1', 'c1'],
              mType: 'mainCall',
              isHold: false,
              holdTimestamp: null,
            },
          },
        } as any,
      });

      primeConferencing(service, conferenceData);
      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: otherLeft,
      });
      expect(service.getSnapshot().value).not.toBe(TaskState.WRAPPING_UP);
    });

    it('downgrades to HELD on HOLD_SUCCESS when no other agents remain on task', () => {
      const service = startMachine();
      const conferenceTaskData = createSingleAgentConferenceTaskData('conference');
      const heldTaskData = createSingleAgentConferenceTaskData('hold', true);

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.HOLD_SUCCESS,
        mediaResourceId: heldTaskData.mediaResourceId,
        taskData: heldTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.HELD);
    });

    it('downgrades to CONNECTED on UNHOLD_SUCCESS when no other agents remain on task', () => {
      const service = startMachine();
      const conferenceTaskData = createSingleAgentConferenceTaskData('conference');
      const connectedTaskData = createSingleAgentConferenceTaskData('connected', false);

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.UNHOLD_SUCCESS,
        mediaResourceId: connectedTaskData.mediaResourceId,
        taskData: connectedTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('downgrades to CONNECTED on PARTICIPANT_LEAVE when the current agent remains', () => {
      const service = startMachine();
      const conferenceTaskData = createSingleAgentConferenceTaskData('conference');
      const connectedTaskData = createSingleAgentConferenceTaskData('connected');

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-2',
        taskData: connectedTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('terminates instead of downgrading when PARTICIPANT_LEAVE identifies the current agent', () => {
      const service = startMachine();
      const conferenceTaskData = createSingleAgentConferenceTaskData('conference');
      const connectedTaskData = {
        ...createSingleAgentConferenceTaskData('connected'),
        wrapUpRequired: false,
      };

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        participantId: 'agent-1',
        taskData: connectedTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('returns to CONNECTED when CTQ cancel arrives before queue connects', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});

      service.send({
        type: TaskEvent.CONSULT,
        destination: 'queue-1',
        destinationType: 'queue',
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      service.send({type: TaskEvent.CTQ_CANCEL});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('returns to CONNECTED when CTQ consult fails', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});

      service.send({
        type: TaskEvent.CONSULT,
        destination: 'queue-1',
        destinationType: 'queue',
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      service.send({type: TaskEvent.CONSULT_FAILED, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });
  });

  describe('failure scenarios', () => {
    it('returns to CONNECTED when HOLD fails', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HOLD_INITIATING);

      service.send({
        type: TaskEvent.HOLD_FAILED,
        mediaResourceId: taskData.mediaResourceId,
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('falls back to HELD when UNHOLD fails', () => {
      const service = startMachine();
      const taskData = createTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      service.send({type: TaskEvent.UNHOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.RESUME_INITIATING);

      service.send({type: TaskEvent.UNHOLD_FAILED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);
    });
  });

  describe('CONF_INITIATING state event handlers', () => {
    it('transitions to CONFERENCING on CONFERENCE_START', () => {
      const service = startMachine();
      const taskData = createTaskData({consultingAgentId: 'agent-1'});

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);

      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    });

    it('transitions to WRAPPING_UP on CONSULT_END with isTerminated during CONF_INITIATING', () => {
      const service = startMachine();
      const taskData = createTaskData({consultingAgentId: 'agent-1'});

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);

      const terminatedTaskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          isTerminated: true,
          owner: 'agent-1',
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_END, taskData: terminatedTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions to CONNECTED on CONSULT_END without isTerminated during CONF_INITIATING', () => {
      const service = startMachine();
      const taskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);

      service.send({type: TaskEvent.CONSULT_END, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });
  });

  describe('CONFERENCING state CONSULT_FAILED ANOTHER_CONSULT_IN_PROGRESS (CAI-8329)', () => {
    it('keeps hideBlindTransfer flag and hides transfer after secondary consult rejected from Agent Desktop', () => {
      const service = startMachine();
      const agentId = 'agent-1';
      const consultMediaId = 'consult-media-1';
      const baseTaskData = createTaskData({
        agentId,
        consultingAgentId: agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        interaction: {
          state: 'conference',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          participants: {
            [agentId]: {
              id: agentId,
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'conferencing',
            },
            '+13159998059': {id: '+13159998059', pType: 'EP-DN', hasLeft: false},
            '+14696762938': {
              id: '+14696762938',
              pType: 'Customer',
              hasJoined: true,
              hasLeft: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['+14696762938', agentId],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998059', agentId],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: baseTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: baseTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: '+13159998059',
        destinationType: 'entryPoint',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: baseTaskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: baseTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
      expect(service.getSnapshot().context.hideBlindTransferForEpDnPendingMerge).toBe(true);

      const consultFailedTaskData = createTaskData({
        agentId,
        consultingAgentId: agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        destinationType: 'Agent',
        reason: 'ANOTHER_CONSULT_IN_PROGRESS',
        type: 'AgentConsultFailed' as any,
        interaction: {
          state: 'conference',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          participants: {
            [agentId]: {
              id: agentId,
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'conferencing',
            },
            '+13159998059': {id: '+13159998059', pType: 'EP-DN', hasLeft: false},
            '+14696762938': {
              id: '+14696762938',
              pType: 'Customer',
              hasJoined: true,
              hasLeft: false,
            },
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['+14696762938', agentId],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998059', agentId],
              isHold: false,
            },
          },
        } as any,
      });
      service.send({
        type: TaskEvent.CONSULT_FAILED,
        taskData: consultFailedTaskData,
        reason: 'ANOTHER_CONSULT_IN_PROGRESS',
      });

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.CONFERENCING);
      expect(snapshot.context.hideBlindTransferForEpDnPendingMerge).toBe(true);
      expect(snapshot.context.uiControls.main.transfer).toEqual({
        isVisible: false,
        isEnabled: false,
      });
      expect(snapshot.context.uiControls.main.consult).toEqual({isVisible: true, isEnabled: false});
    });
  });

  describe('CONFERENCING state TASK_WRAPUP after EP-DN post-call (CAI-8329)', () => {
    it('transitions to WRAPPING_UP on AgentWrapup while in CONFERENCING post_call', () => {
      const service = startMachine();
      const agentId = 'agent-1';
      const consultMediaId = 'consult-media-1';
      const baseTaskData = createTaskData({
        agentId,
        consultingAgentId: agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        interaction: {
          state: 'conference',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          participants: {
            [agentId]: {
              id: agentId,
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'conferencing',
            },
            '+13159998059': {id: '+13159998059', pType: 'EP-DN', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasJoined: true, hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['customer-1', agentId],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998059', agentId],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: baseTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: baseTaskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: '+13159998059',
        destinationType: 'entryPoint',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: baseTaskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: baseTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      const postCallTaskData = createTaskData({
        agentId,
        consultMediaResourceId: consultMediaId,
        isConsulted: false,
        type: 'ParticipantPostCallActivity' as any,
        interaction: {
          state: 'post_call',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          isTerminated: false,
          callProcessingDetails: {hasCustomerLeft: 'true'},
          participants: {
            [agentId]: {
              id: agentId,
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'conferencing',
              currentState: 'post_call',
            },
            '+13159998059': {id: '+13159998059', pType: 'EP-DN', hasLeft: false},
            '+14696762938': {id: '+14696762938', pType: 'Customer', hasJoined: true, hasLeft: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: [agentId],
              isHold: false,
            },
            [consultMediaId]: {
              mediaResourceId: consultMediaId,
              mType: 'consult',
              participants: ['+13159998059', agentId],
              isHold: false,
            },
          },
        } as any,
      });
      service.send({type: TaskEvent.PARTICIPANT_LEAVE, taskData: postCallTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
      expect(service.getSnapshot().context.hideBlindTransferForEpDnPendingMerge).toBe(true);

      const wrapupTaskData = createTaskData({
        agentId,
        wrapUpRequired: true,
        type: 'AgentWrapup' as any,
        interaction: {
          state: 'post_call',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
          owner: agentId,
          isTerminated: true,
          participants: {
            [agentId]: {
              id: agentId,
              pType: 'Agent',
              hasJoined: true,
              hasLeft: false,
              consultState: 'consultCompleted',
              isWrapUp: true,
            },
            '+14696762938': {id: '+14696762938', pType: 'Customer', hasJoined: true, hasLeft: true},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: [],
              isHold: false,
            },
          },
        } as any,
      });
      service.send({type: TaskEvent.TASK_WRAPUP, taskData: wrapupTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });
  });

  describe('CONFERENCING state CONSULT_END with terminated interaction', () => {
    it('transitions to WRAPPING_UP when CONSULT_END arrives with isTerminated in CONFERENCING', () => {
      const service = startMachine();
      const taskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({
        type: TaskEvent.CONSULT,
        destination: 'agent-42',
        destinationType: 'agent',
      });
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      const terminatedTaskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          isTerminated: true,
          owner: 'agent-1',
          state: 'conference',
        } as any,
      });
      service.send({type: TaskEvent.CONSULT_END, taskData: terminatedTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });
  });

  describe('OFFERED state event handlers', () => {
    it('transitions to TERMINATED when customer disconnects before agent answers', () => {
      const service = startMachine();
      const taskData = createTaskData({isConsulted: false});

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      service.send({type: TaskEvent.CONTACT_ENDED, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('transitions to TERMINATED when consulted agent does not answer', () => {
      const service = startMachine();
      const taskData = createTaskData({
        isConsulted: true,
        consultingAgentId: 'agent-1',
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      service.send({type: TaskEvent.CONSULT_FAILED, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('emits only consult-end when an unaccepted consulted offer is ended', () => {
      const emitTaskConsultEnd = jest.fn();
      const emitTaskEnd = jest.fn();
      const service = createActor(
        createTaskStateMachine(createConfig(), {
          actions: {emitTaskConsultEnd, emitTaskEnd},
        })
      );
      service.start();
      const taskData = createTaskData({isConsulted: true, consultingAgentId: 'agent-1'});

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.CONSULT_END, taskData});

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(emitTaskConsultEnd).toHaveBeenCalledTimes(1);
      expect(emitTaskEnd).not.toHaveBeenCalled();
    });

    it('transitions to WRAPPING_UP on TASK_WRAPUP when wrapup is required', () => {
      const service = startMachine();
      const offerTaskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: offerTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      const wrapupTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        wrapUpRequired: true,
        interaction: {
          outboundType: 'OUTDIAL',
          state: 'wrapUp',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.TASK_WRAPUP, taskData: wrapupTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('emits wrap-up once on TASK_WRAPUP from OFFERED when wrapup is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine(createConfig(), {actions: {emitTaskWrapup}})
      );
      service.start();
      const offerTaskData = createTaskData({
        interaction: {outboundType: 'OUTDIAL'} as any,
      });
      service.send({type: TaskEvent.TASK_INCOMING, taskData: offerTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      const wrapupTaskData = createTaskData({
        agentId: 'agent-1',
        wrapUpRequired: true,
        interaction: {outboundType: 'OUTDIAL', state: 'wrapUp', isTerminated: true} as any,
      });
      service.send({type: TaskEvent.TASK_WRAPUP, taskData: wrapupTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });
  });

  describe('OUTBOUND_FAILED handling', () => {
    it('transitions from IDLE to TERMINATED on OUTBOUND_FAILED (race condition)', () => {
      const service = startMachine();
      expect(service.getSnapshot().value).toBe(TaskState.IDLE);

      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });

      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData, reason: 'CUSTOMER_BUSY'});
      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('transitions from OFFERED to TERMINATED on OUTBOUND_FAILED without wrapup', () => {
      const service = startMachine();
      const offerTaskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: offerTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      const failedTaskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({
        type: TaskEvent.OUTBOUND_FAILED,
        taskData: failedTaskData,
        reason: 'CUSTOMER_BUSY',
      });
      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('transitions from OFFERED to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const offerTaskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: offerTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.OFFERED);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({
        type: TaskEvent.OUTBOUND_FAILED,
        taskData: failedTaskData,
        reason: 'CUSTOMER_BUSY',
      });
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from CONNECTED to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const offerTaskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: offerTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: offerTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from HELD to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HELD);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from CONSULTING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-42', destinationType: 'agent'});
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from CONFERENCING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-42', destinationType: 'agent'});
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from HOLD_INITIATING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.HOLD_INITIATING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from RESUME_INITIATING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.HOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      service.send({type: TaskEvent.HOLD_SUCCESS, mediaResourceId: taskData.mediaResourceId});
      service.send({type: TaskEvent.UNHOLD_INITIATED, mediaResourceId: taskData.mediaResourceId});
      expect(service.getSnapshot().value).toBe(TaskState.RESUME_INITIATING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from CONSULT_INITIATING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-42', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });

    it('transitions from CONF_INITIATING to WRAPPING_UP on OUTBOUND_FAILED when wrapup is required', () => {
      const service = startMachine();
      const taskData = createTaskData({
        consultingAgentId: 'agent-1',
        interaction: {
          outboundType: 'OUTDIAL',
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-42', destinationType: 'agent'});
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      expect(service.getSnapshot().value).toBe(TaskState.CONF_INITIATING);

      const failedTaskData = createTaskData({
        agentId: 'agent-1',
        agentsPendingWrapUp: ['agent-1'],
        interaction: {
          outboundType: 'OUTDIAL',
          isTerminated: true,
        } as any,
      });
      service.send({type: TaskEvent.OUTBOUND_FAILED, taskData: failedTaskData, reason: 'AGENT_ENDS'});
      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
    });
  });

  describe('CONSULTING state TRANSFER_CONFERENCE_SUCCESS desktop-initiated (CAI-8329)', () => {
    const startAgent2Machine = () => {
      const actor = createActor(createTaskStateMachine({...createConfig(), agentId: 'agent-2'}));
      actor.start();

      return actor;
    };

    const createSecondaryAgentConferenceBaseTaskData = () =>
      createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

    const createSecondaryAgentConsultingTaskData = () =>
      createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        consultingAgentId: 'agent-2',
        type: 'AgentConferenceTransferred' as any,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: false,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-2', 'agent-3'],
              isHold: false,
            },
          },
        } as any,
      });

    const createSecondaryAgentRemovedTaskData = () =>
      createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'arbitrary-main-media-key': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'customer-1'],
              isHold: false,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-2', 'agent-3'],
              isHold: false,
            },
          },
        } as any,
      });

    const setupSecondaryAgentConsultingFromConference = (
      service: ReturnType<typeof startAgent2Machine>
    ) => {
      const conferenceTaskData = createSecondaryAgentConferenceBaseTaskData();
      const consultingTaskData = createSecondaryAgentConsultingTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData: consultingTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultInitiator).toBe(true);
      expect(service.getSnapshot().context.consultFromConference).toBe(true);
    };

    const setupSecondaryAgentDesktopConsultingFromConference = (
      service: ReturnType<typeof startAgent2Machine>
    ) => {
      const conferenceTaskData = createSecondaryAgentConferenceBaseTaskData();
      const consultingTaskData = createSecondaryAgentConsultingTaskData();
      const consultingActivePayload = {
        ...consultingTaskData,
        type: 'AgentConsulting' as any,
      };
      delete (consultingActivePayload as {consultingAgentId?: string}).consultingAgentId;

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
        taskData: consultingActivePayload,
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultFromConference).toBe(true);
    };

    it('terminates secondary agent on true desktop path without widgets CONSULT event', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentDesktopConsultingFromConference(service);

      const transferSuccessTaskData = createSecondaryAgentConsultingTaskData();
      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: transferSuccessTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('terminates secondary agent on widgets-initiated consult conference transfer from CONSULTING', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentConsultingFromConference(service);

      const transferSuccessTaskData = createSecondaryAgentConsultingTaskData();
      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: transferSuccessTaskData,
      });

      const snapshot = service.getSnapshot();
      expect(snapshot.value).toBe(TaskState.TERMINATED);
      expect(snapshot.context.consultInitiator).toBe(false);
      expect(snapshot.context.consultFromConference).toBe(false);
    });

    it('moves consultee to CONFERENCING when primary agent conference-transfers', () => {
      const startAgent3Machine = () => {
        const actor = createActor(createTaskStateMachine({...createConfig(), agentId: 'agent-3'}));
        actor.start();

        return actor;
      };

      const conferenceTaskData = createTaskData({
        agentId: 'agent-3',
        isConsulted: true,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'agent-3', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

      const consultingTaskData = createTaskData({
        agentId: 'agent-3',
        isConsulted: true,
        consultingAgentId: 'agent-1',
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        consultMediaResourceId: 'consult-media-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: false,
            },
            'consult-media-1': {
              mediaResourceId: 'consult-media-1',
              mType: 'consult',
              participants: ['agent-1', 'agent-3'],
              isHold: false,
            },
          },
        } as any,
      });

      const transferSuccessTaskData = createTaskData({
        agentId: 'agent-3',
        isConsulted: true,
        consultingAgentId: 'agent-1',
        wrapUpRequired: false,
        type: 'AgentConferenceTransferred' as any,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: true,
              consultState: 'conferencing',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-2', 'agent-3', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

      const service = startAgent3Machine();
      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({
        type: TaskEvent.CONSULTING_ACTIVE,
        consultDestinationAgentJoined: true,
        taskData: consultingTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);
      expect(service.getSnapshot().context.consultInitiator).toBe(false);

      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: transferSuccessTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    });

    it('passive observer stays in CONFERENCING when another agent conference-transfers', () => {
      const service = startAgent2Machine();
      const conferenceTaskData = createSecondaryAgentConferenceBaseTaskData();
      const transferSuccessTaskData = createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        type: 'AgentConferenceTransferred' as any,
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'conferencing',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'agent-3', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
      expect(service.getSnapshot().context.consultInitiator).toBe(false);

      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: transferSuccessTaskData,
      });
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);
    });

    it('terminates secondary agent on widgets-initiated conference transfer regression', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentConsultingFromConference(service);

      const transferSuccessTaskData = createSecondaryAgentConsultingTaskData();
      service.send({type: TaskEvent.TRANSFER_CONFERENCE});
      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: transferSuccessTaskData,
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('emits wrap-up once on TRANSFER_CONFERENCE_SUCCESS from CONSULTING when wrap-up is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine({...createConfig(), agentId: 'agent-1'}, {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        agentId: 'agent-1',
        consultingAgentId: 'agent-1',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-2', destinationType: 'agent'});
      service.send({type: TaskEvent.CONSULT_SUCCESS, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      service.send({type: TaskEvent.TRANSFER_CONFERENCE});
      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: {...taskData, wrapUpRequired: true},
      });

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('emits wrap-up once on TRANSFER_CONFERENCE_SUCCESS from CONFERENCING when wrap-up is required', () => {
      const {emitTaskWrapup, publishWrapup} = createPublishAwareEmitTaskWrapupMock();
      const service = createActor(
        createTaskStateMachine({...createConfig(), agentId: 'agent-1'}, {actions: {emitTaskWrapup}})
      );
      service.start();
      const taskData = createTaskData({
        agentId: 'agent-1',
        interaction: {
          owner: 'agent-1',
          state: 'conference',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', type: 'Agent', hasJoined: true, hasLeft: false},
          },
        } as any,
      });

      service.send({type: TaskEvent.TASK_INCOMING, taskData});
      service.send({type: TaskEvent.ASSIGN, taskData});
      service.send({type: TaskEvent.MERGE_TO_CONFERENCE});
      service.send({type: TaskEvent.CONFERENCE_START, taskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONFERENCING);

      service.send({type: TaskEvent.TRANSFER_CONFERENCE});
      service.send({
        type: TaskEvent.TRANSFER_CONFERENCE_SUCCESS,
        taskData: {...taskData, wrapUpRequired: true},
      });

      expect(service.getSnapshot().value).toBe(TaskState.WRAPPING_UP);
      expect(publishWrapup).toHaveBeenCalledTimes(1);
    });

    it('terminates secondary agent on PARTICIPANT_LEAVE while in CONSULTING during conference', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentDesktopConsultingFromConference(service);

      const selfLeftTaskData = createTaskData({
        agentId: 'agent-2',
        isConsulted: true,
        participantId: 'agent-2',
        interactionId: 'interaction-1',
        mediaResourceId: 'interaction-1',
        interaction: {
          state: 'conference',
          owner: 'agent-1',
          mainInteractionId: 'interaction-1',
          interactionId: 'interaction-1',
          participants: {
            'agent-1': {
              id: 'agent-1',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'conferencing',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-3', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({
        type: TaskEvent.PARTICIPANT_LEAVE,
        taskData: selfLeftTaskData,
        participantId: 'agent-2',
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('terminates secondary agent on PARTICIPANT_LEAVE while consult is initiating', () => {
      const service = startAgent2Machine();
      const conferenceTaskData = createSecondaryAgentConferenceBaseTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);
      expect(service.getSnapshot().context.taskData.interaction).toBe(
        conferenceTaskData.interaction
      );
      expect(service.getSnapshot().context.taskData.destAgentId).toBe('agent-3');

      const participantLeaveEvent = {
        type: TaskEvent.PARTICIPANT_LEAVE,
        taskData: createSecondaryAgentRemovedTaskData(),
      } as const;
      expect(
        guards.didCurrentAgentLeaveMainInteraction({
          context: service.getSnapshot().context,
          event: participantLeaveEvent,
        })
      ).toBe(true);

      service.send(participantLeaveEvent);

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('terminates secondary agent on CONSULT_END while consult is initiating', () => {
      const service = startAgent2Machine();
      const conferenceTaskData = createSecondaryAgentConferenceBaseTaskData();

      service.send({type: TaskEvent.TASK_INCOMING, taskData: conferenceTaskData});
      service.send({type: TaskEvent.ASSIGN, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONFERENCE_START, taskData: conferenceTaskData});
      service.send({type: TaskEvent.CONSULT, destination: 'agent-3', destinationType: 'agent'});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULT_INITIATING);

      const consultEndEvent = {
        type: TaskEvent.CONSULT_END,
        taskData: createSecondaryAgentRemovedTaskData(),
      } as const;
      expect(
        guards.didCurrentAgentLeaveMainInteraction({
          context: service.getSnapshot().context,
          event: consultEndEvent,
        })
      ).toBe(true);

      service.send(consultEndEvent);

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
    });

    it('terminates a consulting secondary initiator when CONSULT_END removes it from mainCall', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentConsultingFromConference(service);

      service.send({
        type: TaskEvent.CONSULT_END,
        taskData: createSecondaryAgentRemovedTaskData(),
      });

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(service.getSnapshot().context.consultInitiator).toBe(false);
      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(false);
    });

    it('does not infer departure from a partial CONSULT_END payload', () => {
      const service = startAgent2Machine();
      setupSecondaryAgentConsultingFromConference(service);
      const partialTaskData = {
        ...createTaskData({agentId: 'agent-2', interactionId: 'interaction-1'}),
        interaction: {
          state: 'conference',
          interactionId: 'interaction-1',
          mainInteractionId: 'interaction-1',
        },
      } as any;

      const consultEndEvent = {type: TaskEvent.CONSULT_END, taskData: partialTaskData} as const;
      expect(service.getSnapshot().context.consultInitiator).toBe(true);
      expect(
        guards.didCurrentAgentLeaveMainInteraction({
          context: service.getSnapshot().context,
          event: consultEndEvent,
        })
      ).toBe(false);

      service.send(consultEndEvent);

      expect(service.getSnapshot().value).toBe(TaskState.CONNECTED);
    });

    it('emits consult-end and task-end when AgentConsultEnded terminates the consulted agent', () => {
      const emitTaskConsultEnd = jest.fn();
      const emitTaskEnd = jest.fn();
      const cleanupResources = jest.fn();
      const service = createActor(
        createTaskStateMachine(
          {...createConfig(), agentId: 'agent-3'},
          {
            actions: {emitTaskConsultEnd, emitTaskEnd, cleanupResources},
          }
        )
      );
      service.start();

      const consultingTaskData = createTaskData({
        agentId: 'agent-3',
        isConsulted: true,
        interactionId: 'consult-child',
        interaction: {
          state: 'consulting',
          owner: 'agent-1',
          interactionId: 'consult-child',
          mainInteractionId: 'interaction-1',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'agent-2': {
              id: 'agent-2',
              pType: 'Agent',
              hasLeft: false,
              consultState: 'consulting',
            },
            'agent-3': {
              id: 'agent-3',
              pType: 'Agent',
              hasLeft: false,
              isConsulted: true,
              consultState: 'consulting',
            },
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: true,
            },
            'consult-child': {
              mediaResourceId: 'consult-child',
              mType: 'consult',
              participants: ['agent-2', 'agent-3'],
              isHold: false,
            },
          },
        } as any,
      });
      service.send({type: TaskEvent.HYDRATE, taskData: consultingTaskData});
      expect(service.getSnapshot().value).toBe(TaskState.CONSULTING);

      const consultEndedTaskData = createTaskData({
        ...consultingTaskData,
        type: 'AgentConsultEnded' as any,
        interaction: {
          ...consultingTaskData.interaction,
          state: 'conference',
          participants: {
            'agent-1': {id: 'agent-1', pType: 'Agent', hasLeft: false},
            'agent-2': {id: 'agent-2', pType: 'Agent', hasLeft: false},
            'customer-1': {id: 'customer-1', pType: 'Customer', hasLeft: false},
          },
          media: {
            'interaction-1': {
              mediaResourceId: 'interaction-1',
              mType: 'mainCall',
              participants: ['agent-1', 'agent-2', 'customer-1'],
              isHold: false,
            },
          },
        } as any,
      });

      service.send({type: TaskEvent.CONSULT_END, taskData: consultEndedTaskData});

      expect(service.getSnapshot().value).toBe(TaskState.TERMINATED);
      expect(emitTaskConsultEnd).toHaveBeenCalledTimes(1);
      expect(emitTaskEnd).toHaveBeenCalledTimes(1);
      expect(cleanupResources).toHaveBeenCalledTimes(1);
      expect(service.getSnapshot().context.consultDestinationAgentJoined).toBe(false);
      expect(service.getSnapshot().context.consultInitiator).toBe(false);
    });
  });
});
